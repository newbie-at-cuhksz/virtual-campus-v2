﻿#if UNITY_ANDROID
using System;
using UnityEngine;
using VoxelBusters.EssentialKit.Internal;

namespace VoxelBusters.EssentialKit.MediaServicesCore.Android
{
    internal class SelectPhotoProxyListener : NativeProxy<SelectImageInternalCallback>
    {
        #region Constructors

        public SelectPhotoProxyListener(SelectImageInternalCallback callback) : base(callback, Native.kRequestCameraAccessListener)
        {
        }

        #endregion

        #region Callbacks

        private void onSelectPhotoComplete(byte[] data, string error)
        {
            if (m_callback != null)
            {
                Action action = () =>
                {
                    m_callback(data, error);
                };
                DispatchOnMainThread(action);
            }

        }

        public override AndroidJavaObject Invoke(string methodName, AndroidJavaObject[] javaArgs)
        {
            if (methodName == "onSelectPhotoComplete")
            {
                byte[] data     = javaArgs[0].GetArray<byte[]>();
                string error    = javaArgs[1].GetString();

                onSelectPhotoComplete(data, error);
                return null;
            }
            else
            {
                return base.Invoke(methodName, javaArgs);
            }
        }

        #endregion
    }
}
#endif