﻿namespace VoxelBusters.EssentialKit.WebViewCore.Android
{
    internal interface INativeWebViewStateListener
    {
        void OnShow(string error);

        void OnHide(string error);

        void OnLoadStart(string error);

        void OnLoadFinish(string error);

        void OnURLSchemeMatchFound(string url);
    }
}