﻿#if UNITY_ANDROID
using System;

namespace VoxelBusters.EssentialKit.GameServicesCore.Android
{
    using Internal;

    internal class ReportProgressProxyListener : NativeProxy<ReportAchievementProgressInternalCallback>
    {
        #region Constructors

        public ReportProgressProxyListener(ReportAchievementProgressInternalCallback callback) : base(callback, Native.Achievement.kReportProgressListenerInterface)
        {
        }

        #endregion

        #region Callbacks

        private void onReportProgressComplete(string error)
        {
            if (m_callback != null)
            {
                Action action = () => m_callback(error);
                DispatchOnMainThread(action);
            }
        }

        #endregion
    }
}
#endif