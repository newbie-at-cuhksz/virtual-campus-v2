﻿namespace VoxelBusters.EssentialKit.MediaServicesCore.Android
{
    #region Data types

    internal enum AndroidCameraAccessStatus
    {
        NotDetermined,
        Restricted,
        Denied,
        Authorized,
    }

    #endregion
}