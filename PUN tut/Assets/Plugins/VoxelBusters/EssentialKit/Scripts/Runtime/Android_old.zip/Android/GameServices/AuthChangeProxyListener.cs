﻿#if UNITY_ANDROID
using System;

namespace VoxelBusters.EssentialKit.GameServicesCore.Android
{
    using System.Collections.Generic;
    using Internal;
    using UnityEngine;

    internal class AuthChangeProxyListener : NativeProxy<AuthChangeInternalCallback>
    {
        #region Constructors

        public AuthChangeProxyListener(AuthChangeInternalCallback callback) : base(callback, Native.LocalPlayer.kAuthChangeListenerInterface)
        {
        }

        #endregion

        #region Callbacks

        private void onAuthChange(bool isAuthenticated, string error)
        {
            if (m_callback != null)
            {
                Action action = () => m_callback(isAuthenticated ? LocalPlayerAuthStatus.Authenticated : LocalPlayerAuthStatus.NotAvailable, error); //@@ Handle is connecting
                DispatchOnMainThread(action);
            }
        }

        #endregion
    }
}
#endif