﻿#if UNITY_ANDROID
using System;
using System.Collections;
using UnityEngine;
using VoxelBusters.EssentialKit.Internal;

namespace VoxelBusters.EssentialKit.CloudServicesCore.Android
{
    internal class CloudServicesInterface : NativeCloudServicesInterfaceBase
    {
        #region Properties

        private AndroidJavaObject Plugin
        {
            get;
            set;
        }

        #endregion

        #region Constructors

        public CloudServicesInterface()
        {
            Plugin = AndroidPluginUtility.CreateJavaInstance(Native.kClassName);
            Plugin.Call(Native.Method.kSetUserChangeListener, new UserChangeProxyListener(InvokeOnUserChange));
            Plugin.Call(Native.Method.kSetSavedDataChangeListener, new SavedDataChangeProxyListener(InvokeOnSavedDataChange)); 
        }

        #endregion

        #region Base implementation

        public override bool GetBool(string key)
        {
            return Plugin.Call<bool>(Native.Method.kGetBool);
        }

        public override long GetLong(string key)
        {
            return Plugin.Call <long>(Native.Method.kGetLong);
        }

        public override double GetDouble(string key)
        {
            return Plugin.Call<double>(Native.Method.kGetDouble);
        }

        public override string GetString(string key)
        {
            return Plugin.Call<string>(Native.Method.kGetString);
        }

        public override byte[] GetByteArray(string key)
        {
            string jsonString = GetString(key);

            return (byte[])ExternalServiceProvider.JsonServiceProvider.FromJson(jsonString);
        }

        /*public override object[] GetArray(string key)
        {
            string jsonString = GetString(key);
            return (object[])ExternalServiceProvider.JsonServiceProvider.FromJson(jsonString);
        }

        public override IDictionary GetDictionary(string key)
        {
            string jsonString = GetString(key);
            return (IDictionary)ExternalServiceProvider.JsonServiceProvider.FromJson(jsonString);
        }*/

        public override void SetBool(string key, bool value)
        {
            Plugin.Call(Native.Method.kSetBool, key, value);
        }

        public override void SetLong(string key, long value)
        {
            Plugin.Call(Native.Method.kSetLong, key, value);
        }

        public override void SetDouble(string key, double value)
        {
            Plugin.Call(Native.Method.kSetDouble, key, value);
        }

        public override void SetString(string key, string value)
        {
            Plugin.Call(Native.Method.kSetString, key, value);
        }

        public override void SetByteArray(string key, byte[] value)
        {
            Plugin.Call(Native.Method.kSetString, key, ExternalServiceProvider.JsonServiceProvider.ToJson(value));
        }

        /*public override void SetArray(string key, Array value)
        {
            Plugin.Call(Native.Method.kSetArray, key, ExternalServiceProvider.JsonServiceProvider.ToJson(value));
        }

        public override void SetDictionary(string key, IDictionary value)
        {
            Plugin.Call(Native.Method.kSetDictionary, key, ExternalServiceProvider.JsonServiceProvider.ToJson(value));
        }*/

        public override void RemoveKey(string key)
        {
            Plugin.Call(Native.Method.kRemoveKey, key);
        }

        public override void Synchronize(SynchronizeInternalCallback callback)
        {
            Plugin.Call(Native.Method.kSyncronize, new SyncronizeProxyListener(callback));
        }

        public override IDictionary GetSnapshot()
        {
            string cloudJsonData = Plugin.Call<string>(Native.Method.kGetSnapshotData);
            return (IDictionary)ExternalServiceProvider.JsonServiceProvider.FromJson(cloudJsonData);
        }

        #endregion

        #region Nested classes

        internal class Native
        {
            #region Constant fields

            internal const string kPackage                          = "com.voxelbusters.nativeplugins.v2.features.cloudservices";
            internal const string kClassName                        = kPackage + "." + "CloudServicesHandler";
            internal const string kSyncronizeListenerInterface      = kPackage + "." + "ICloudServices$ISyncronizeListener";
            internal const string kUserChangeListenerInterface      = kPackage + "." + "ICloudServices$IUserChangeListener";
            internal const string kSavedDataChangeListenerInterface = kPackage + "." + "ICloudServices$ISavedDataChangeListener";


            #endregion

            #region Nested types

            internal class Method
            {
                internal const string kGetBool                          = "getBool";
                internal const string kGetLong                          = "getLong";
                internal const string kGetDouble                        = "getDouble";
                internal const string kGetString                        = "getString";
                internal const string kSetBool                          = "setBool";
                internal const string kSetLong                          = "setLong";
                internal const string kSetDouble                        = "setDouble";
                internal const string kSetString                        = "setString" ;
                internal const string kSetArray                         = "setArray";
                internal const string kSetDictionary                    = "setDictionary";
                internal const string kRemoveKey                        = "removeKey";
                internal const string kRemoveAllKeys                    = "removeAllKeys";
                internal const string kSyncronize                       = "syncronize";
                internal const string kGetSnapshotData                  = "getSnapshotData";
                internal const string kSetUserChangeListener            = "setUserChangeListener";
                internal const string kSetSavedDataChangeListener       = "setSavedDataChangeListener";
            }

            #endregion
        }

        #endregion

    }
}
#endif