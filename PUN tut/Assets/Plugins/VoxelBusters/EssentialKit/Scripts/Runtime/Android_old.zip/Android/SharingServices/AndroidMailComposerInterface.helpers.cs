﻿#if UNITY_ANDROID
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace VoxelBusters.EssentialKit.SharingServicesCore.Android
{
    using Internal;
    using VoxelBusters.NativePlugins.Internal;

    internal partial class AndroidMailComposerInterface : NativeMailComposerBase
    {
        #region Platform native Info

        private class Native
        {
            #region Fields

            internal const string kPackage                          = "com.voxelbusters.nativeplugins.v2.features.sharing";
            internal const string kClassName                        = kPackage + "." + "MailComposer";
            internal const string kMailComposerProxyInterface       = kPackage + "." + "ISharing$IMailComposerListener";

            #endregion


            #region Nested types

            internal class Method
            {
                internal const string kCanSendMail                  = "canSendMail";
                internal const string kGetMessage                   = "getMessage";
                internal const string kGetTitle                     = "getTitle";
                internal const string kSetMessage                   = "setMessage";
                internal const string kSetTitle                     = "setTitle";
                internal const string kSetBcc                       = "setBccRecipients";
                internal const string kSetToRecipients              = "setToRecipients";
                internal const string kSetCcRecipients              = "setCcRecipients";
                internal const string kAddAttachmentData            = "addAttachmentData";
                internal const string kAddFileAtPathAsync           = "addFileAtPathAsync";
                internal const string kShow                         = "show";
            }

            #endregion
        }

        #endregion

        #region Proxy listeners

        internal class MailComposerProxyListener : NativeProxy<MailComposerClosedInternalCallback>
        {
            #region Constructors

            public MailComposerProxyListener(MailComposerClosedInternalCallback callback) : base(callback, Native.kMailComposerProxyInterface)
            { }

            #endregion

            #region Callbacks

            private void onAction(AndroidMailComposerResultCode resultCode)
            {
                if (m_callback != null)
                {
                    DispatchOnMainThread(() => m_callback(Convert(resultCode), null));
                }
            }

            public override AndroidJavaObject Invoke(string methodName, AndroidJavaObject[] javaArgs)
            {
                if (methodName == "onAction")
                {
                    AndroidMailComposerResultCode resultCode = (AndroidMailComposerResultCode)javaArgs[0].Call<int>("ordinal");

                    onAction(resultCode);
                    return null;
                }
                else
                {
                    return base.Invoke(methodName, javaArgs);
                }
            }

            #endregion

            #region Helpers

            private MailComposerResultCode Convert(AndroidMailComposerResultCode resultCode)
            {
                switch (resultCode)
                {
                    case AndroidMailComposerResultCode.Cancelled:
                        return MailComposerResultCode.Cancelled;

                    case AndroidMailComposerResultCode.Sent:
                        return MailComposerResultCode.Sent;

                    case AndroidMailComposerResultCode.Unknown:
                        return MailComposerResultCode.Unknown;

                    default:
                        throw ExceptionFactory.SwitchCaseNotImplementedException(resultCode);
                }
            }

            #endregion
        }

        #endregion

        #region Data types

        internal enum AndroidMailComposerResultCode
        {
            Cancelled,
            Sent,
            Unknown
        }

        #endregion
    }
}
#endif