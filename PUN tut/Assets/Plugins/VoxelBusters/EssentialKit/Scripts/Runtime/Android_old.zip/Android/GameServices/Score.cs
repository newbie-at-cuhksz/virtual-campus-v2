﻿#if UNITY_ANDROID
using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using UnityEngine;
using AOT;
using VoxelBusters.EssentialKit.Internal;

namespace VoxelBusters.EssentialKit.GameServicesCore.Android
{
    internal class Score : ScoreBase
    {
        #region Properties

        private AndroidJavaObject Plugin
        {
            get;
            set;
        }

        #endregion

        #region Constructors

        public Score(string leaderboardId, string leaderboardPlatformId) : base(leaderboardId, leaderboardPlatformId)
        {
            Plugin = AndroidPluginUtility.CreateJavaInstance(Native.Score.kClassName, true, leaderboardPlatformId);
        }

        public Score(AndroidJavaObject nativeObject) : base(nativeObject.Get<string>("getLeaderboardId"))
        {
            Plugin = nativeObject;
        }

        #endregion

        #region Base class methods

        protected override IPlayer GetPlayerInternal()
        {
            AndroidJavaObject player = Plugin.Call<AndroidJavaObject>(Native.Score.Method.kGetPlayer);
            return new Player(player);
        }

        protected override long GetRankInternal()
        {
            return Plugin.Call<long>(Native.Score.Method.kGetRank);
        }

        protected override long GetValueInternal()
        {
            return Plugin.Call<long>(Native.Score.Method.kGetValue);
        }

        protected override void SetValueInternal(long value)
        {
            Plugin.Call(Native.Score.Method.kSetValue, value);
        }

        protected override DateTime GetLastReportedDateInternal()
        {
            AndroidJavaObject nativeObject = Plugin.Call<AndroidJavaObject>(Native.Score.Method.kGetLastReportedDate);
            return nativeObject.GetDate();
        }

        protected override void ReportScoreInternal(ReportScoreInternalCallback callback)
        {
            Plugin.Call(Native.Score.Method.kReportScore, new ReportScoreProxyListener(callback));
        }

        #endregion
    }
}
#endif