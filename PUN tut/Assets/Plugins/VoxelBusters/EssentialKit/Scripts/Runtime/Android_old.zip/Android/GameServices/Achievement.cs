﻿#if UNITY_ANDROID
using System;
using UnityEngine;
using VoxelBusters.EssentialKit.Internal;

namespace VoxelBusters.EssentialKit.GameServicesCore.Android
{
    internal class Achievement : AchievementBase
    {
        #region Properties

        private AndroidJavaObject Plugin
        {
            get;
            set;
        }

        #endregion

        #region Constructors

        public Achievement() : base(null)
        {

        }

        public Achievement(AndroidJavaObject nativeObject) : base(nativeObject.Get<string>("getId"))
        {
            Plugin = nativeObject;
        }

        public Achievement(string id, string platformId) : base(id, platformId)
        {
            Plugin = AndroidPluginUtility.CreateJavaInstance(Native.Achievement.kClassName, true, platformId);
        }

        #endregion

        #region Static methods

        public static void LoadAchievements(LoadAchievementsInternalCallback callback)
        {
            using (AndroidJavaClass javaClass = AndroidPluginUtility.CreateJavaClass(Native.Achievement.kClassName))
            {
                javaClass.CallStatic<bool>(Native.Achievement.Method.kLoadAchievements, AndroidPluginUtility.GetContext(), new LoadAchievementsProxyListener(callback));
            }
        }

        public static void ShowAchievementsView(ViewClosedInternalCallback callback)
        {
            using (AndroidJavaClass javaClass = AndroidPluginUtility.CreateJavaClass(Native.Achievement.kClassName))
            {
                javaClass.CallStatic<bool>(Native.Achievement.Method.kShowAchievementView, new ViewClosedProxyListener(callback));
            }
        }

        #endregion

        #region Base class methods

        protected override double GetPercentageCompletedInternal()
        {
            return Plugin.Call<double>(Native.Achievement.Method.kGetPercentageCompleted);
        }

        protected override void SetPercentageCompletedInternal(double value)
        {
            Plugin.Call(Native.Achievement.Method.kSetPercentageCompleted, value);
        }

        protected override bool GetIsCompletedInternal()
        {
            return Plugin.Call<bool>(Native.Achievement.Method.kGetIsCompleted);
        }

        protected override DateTime GetLastReportedDateInternal()
        {
            AndroidJavaObject lastReportedDate = Plugin.Call<AndroidJavaObject>(Native.Achievement.Method.kGetLastReportedDate);
            return lastReportedDate.GetDate();
        }

        protected override void ReportProgressInternal(ReportAchievementProgressInternalCallback callback)
        {
            Plugin.Call(Native.Achievement.Method.kReportProgress, new ReportProgressProxyListener(callback));
        }

        #endregion
    }
}
#endif