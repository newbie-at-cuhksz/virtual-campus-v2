﻿#if UNITY_ANDROID
using System;
using System.Collections.Generic;
using UnityEngine;
using VoxelBusters.EssentialKit.Internal;

namespace VoxelBusters.EssentialKit.BillingServicesCore.Android
{
    internal class RequestForProductsProxyListener : NativeProxy<RetrieveProductsInternalCallback>
    {
        #region Constructors

        public RequestForProductsProxyListener(RetrieveProductsInternalCallback callback) : base(callback, BillingServicesInterface.Native.kRequestProductsListenerInterface)
        {
        }

        #endregion

        #region Callbacks

        private void onRequestProductsComplete(List<BillingProduct> products, List<string> invalidIds, string error)
        {
            if (m_callback != null)
            {
                Action action = () => m_callback((products == null) ? null : products.ToArray(), error, (invalidIds == null) ? null : invalidIds.ToArray());
                DispatchOnMainThread(action);
            }
        }

        public override AndroidJavaObject Invoke(string methodName, AndroidJavaObject[] javaArgs)
        {
            if (methodName == "onRequestProductsComplete")
            {
                List<BillingProduct>            productList = javaArgs[0].GetList(BillingProduct.FromNativeObject);
                List<string>                    invalidIds  = javaArgs[1].GetList<string>();
                string                          error       = javaArgs[2].GetString();

                onRequestProductsComplete(productList, invalidIds, error);
                return null;
            }
            else
            {
                return base.Invoke(methodName, javaArgs);
            }
        }

        #endregion
    }
}
#endif