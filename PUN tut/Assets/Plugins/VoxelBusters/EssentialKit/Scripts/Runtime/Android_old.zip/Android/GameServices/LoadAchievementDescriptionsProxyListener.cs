﻿#if UNITY_ANDROID
using System;

namespace VoxelBusters.EssentialKit.GameServicesCore.Android
{
    using System.Collections.Generic;
    using Internal;
    using UnityEngine;

    internal class LoadAchievementDescriptionsProxyListener : NativeProxy<LoadAchievementDescriptionsInternalCallback>
    {
        #region Constructors

        public LoadAchievementDescriptionsProxyListener(LoadAchievementDescriptionsInternalCallback callback) : base(callback, Native.Achievement.kLoadAchievementsListenerInterface)
        {
        }

        #endregion

        #region Callbacks

        private void onLoadAchievementDescriptionsComplete(IAchievementDescription[] achievements, string error)
        {
            if (m_callback != null)
            {
                Action action = () => m_callback(achievements, error);
                DispatchOnMainThread(action);
            }
        }

        public override AndroidJavaObject Invoke(string methodName, AndroidJavaObject[] javaArgs)
        {
            if (methodName == "onLoadAchievementDescriptionsComplete")
            {
                List<IAchievementDescription> list = javaArgs[0].GetList((AndroidJavaObject nativeObject) => (IAchievementDescription)new AchievementDescription(nativeObject));
                string error            = javaArgs[1].GetString();

                onLoadAchievementDescriptionsComplete(list != null ? list.ToArray() : null, error);
                return null;
            }
            else
            {
                return base.Invoke(methodName, javaArgs);
            }
        }

        #endregion
    }
}
#endif