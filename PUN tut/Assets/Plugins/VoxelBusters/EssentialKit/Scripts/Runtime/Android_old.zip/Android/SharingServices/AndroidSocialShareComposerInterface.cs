﻿#if UNITY_ANDROID
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using VoxelBusters.CoreLibrary;
using VoxelBusters.EssentialKit.Internal;

namespace VoxelBusters.EssentialKit.SharingServicesCore.Android
{
    internal partial class AndroidSocialShareComposerInterface : NativeSocialShareComposerBase
    {
        #region  Properties

        private AndroidJavaObject Plugin
        {
            get;
            set;
        }

        #endregion

        #region Constructors

        public AndroidSocialShareComposerInterface(SocialShareComposerType composerType)
        {
            Plugin = AndroidPluginUtility.CreateJavaInstance(Native.kName);

            // Set composer type
            SetComposerType(GetComposerType(composerType));
        }

        #endregion

        #region Static methods

        public static bool IsComposerAvailable(SocialShareComposerType composerType)
        {
            using (AndroidJavaClass javaClass = AndroidPluginUtility.CreateJavaClass(Native.kName))
            {
                return javaClass.CallStatic<bool>(Native.Method.kIsComposerAvailable, AndroidPluginUtility.GetContext(), GetComposerType(composerType));
            }
        }

        #endregion

        #region INativeShareComposerInterface Implementation

        public override void AddImage(byte[] imageData)
        {
            Plugin.Call(Native.Method.kAddAttachmentData, imageData, MimeType.kPNGImage, "share.png");//TODO find mime type from imageData
        }

        public override void AddScreenshot()
        {
            string filePath = TextureExtensions.TakeScreenshot("screenshot.png");
            Plugin.Call(Native.Method.kAddFileAtPathAsync, filePath, MimeType.kPNGImage);
        }

        public override void AddText(string value)
        {
            Plugin.Call(Native.Method.kSetMessage, value, false);
        }

        public override void AddURL(URLString url)
        {
            Plugin.Call(Native.Method.kSetURL, url.ToString());
        }

        public override void Show(Vector2 screenPosition)
        {
            Plugin.Call(Native.Method.kShow, new SocialShareComposerProxyListener(InvokeOnClose));
        }

        #endregion

        #region Internal Calls

        private void SetComposerType(string type)
        {
            Plugin.Call(Native.Method.kSetComposerType, type);
        }

        #endregion

        #region Helpers

        private static string GetComposerType(SocialShareComposerType composerType)
        {
            switch(composerType)
            {
                case SocialShareComposerType.Facebook:
                    return "facebook";

                case SocialShareComposerType.Twitter:
                    return "twitter";

                case SocialShareComposerType.WhatsApp:
                    return "whatsapp";

                default :
                    return null;
            }
        }

        #endregion
    }
}
#endif