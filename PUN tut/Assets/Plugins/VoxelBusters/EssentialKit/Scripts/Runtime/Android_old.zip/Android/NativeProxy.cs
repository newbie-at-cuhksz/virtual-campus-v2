﻿#if UNITY_ANDROID
using System;
using UnityEngine;

namespace VoxelBusters.EssentialKit.Internal
{
    public abstract class NativeProxyBase : AndroidJavaProxy
    {
        public NativeProxyBase(string interfaceName) : base(interfaceName)
        {
        }

        protected void DispatchOnMainThread(Action action)
        {
            // Dispatch on Unity Thread
            UnityThreadDispatcher.Enqueue(action);
        }
    }

    public class NativeProxy<T> : NativeProxyBase
    {
        protected T m_callback;

        public NativeProxy(T m_callback, string interfaceName) : base(interfaceName)
        {
            this.m_callback = m_callback;
        }
    }
}
#endif