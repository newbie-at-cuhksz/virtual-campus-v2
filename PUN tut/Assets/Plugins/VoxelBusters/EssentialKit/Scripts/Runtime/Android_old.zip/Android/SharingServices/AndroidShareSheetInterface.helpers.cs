﻿#if UNITY_ANDROID
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace VoxelBusters.EssentialKit.SharingServicesCore.Android
{
    using Internal;
    using VoxelBusters.NativePlugins.Internal;

    internal partial class AndroidShareSheetInterface : NativeShareSheetBase
    {
        #region Native platform Info

        private class Native
        {
            internal const string kPackage                      = "com.voxelbusters.nativeplugins.v2.features.sharing";
            internal const string kClassName                    = kPackage + "." + "ShareSheet";
            internal const string kShareSheetListenerInterface  = kPackage + "." + "ISharing$IShareSheetListener";

            internal class Method
            {
                internal const string kSetMessage               = "setMessage";
                internal const string kAddAttachmentData        = "addAttachmentData";
                internal const string kAddFileAtPathAsync       = "addFileAtPathAsync";
                internal const string kSetURL                   = "setUrl";
                internal const string kShow                     = "show";
            }
        }

        #endregion

        #region Proxy listeners

        internal class ShareSheetProxyListener : NativeProxy<ShareSheetClosedInternalCallback>
        {

            #region Constructors

            public ShareSheetProxyListener(ShareSheetClosedInternalCallback callback) : base(callback, Native.kShareSheetListenerInterface)
            {
            }

            #endregion

            #region Callbacks

            private void onAction(AndroidShareSheetResultCode resultCode)
            {
                if (m_callback != null)
                {
                    DispatchOnMainThread(() => m_callback(Convert(resultCode), null));
                }
            }

            public override AndroidJavaObject Invoke(string methodName, AndroidJavaObject[] javaArgs)
            {
                if (methodName == "onAction")
                {
                    AndroidShareSheetResultCode resultCode = (AndroidShareSheetResultCode)javaArgs[0].Call<int>("ordinal");

                    onAction(resultCode);
                    return null;
                }
                else
                {
                    return base.Invoke(methodName, javaArgs);
                }
            }

            #endregion

            #region Helpers

            private ShareSheetResultCode Convert(AndroidShareSheetResultCode resultCode)
            {
                switch (resultCode)
                {
                    case AndroidShareSheetResultCode.Cancelled:
                        return ShareSheetResultCode.Cancelled;

                    case AndroidShareSheetResultCode.Done:
                        return ShareSheetResultCode.Done;

                    case AndroidShareSheetResultCode.Unknown:
                        return ShareSheetResultCode.Unknown;

                    default:
                        throw ExceptionFactory.SwitchCaseNotImplementedException(resultCode);
                }
            }

            #endregion
        }

        #endregion

        #region Data types

        internal enum AndroidShareSheetResultCode
        {
            Cancelled,
            Done,
            Unknown
        }

        #endregion
    }
}
#endif