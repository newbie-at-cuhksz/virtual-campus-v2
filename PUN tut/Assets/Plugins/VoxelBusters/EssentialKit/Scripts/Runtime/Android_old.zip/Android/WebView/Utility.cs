﻿using VoxelBusters.CoreLibrary;
using VoxelBusters.NativePlugins;

namespace VoxelBusters.EssentialKit.WebViewCore.Android
{
    public static class Utility
    {
        internal static WebViewStyle Convert(AndroidWebViewStyle style)
        {
            switch (style)
            {
                case AndroidWebViewStyle.Default:
                    return WebViewStyle.Default;

                case AndroidWebViewStyle.ShowCloseButton:
                    return WebViewStyle.Popup;

                case AndroidWebViewStyle.Browser:
                    return WebViewStyle.Browser;

                default:
                    throw VBException.SwitchCaseNotImplemented(style);
            }
        }

        internal static AndroidWebViewStyle Convert(WebViewStyle style)
        {
            switch (style)
            {
                case WebViewStyle.Default:
                    return AndroidWebViewStyle.Default;

                case WebViewStyle.Popup:
                    return AndroidWebViewStyle.ShowCloseButton;

                case WebViewStyle.Browser:
                    return AndroidWebViewStyle.Browser;

                default:
                    throw VBException.SwitchCaseNotImplemented(style);
            }
        }
    }
}