﻿#if UNITY_ANDROID
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using VoxelBusters.EssentialKit.Internal;

namespace VoxelBusters.EssentialKit.NetworkServicesCore.Android
{
    internal partial class AndroidNetworkServicesInterface : NativeNetworkServicesInterfaceBase
    {
        #region  Properties

        private AndroidJavaObject Plugin
        {
            get;
            set;
        }

        #endregion

        #region Constructors

        public AndroidNetworkServicesInterface(NetworkServicesSettings settings) : base(settings)
        {

            //TODO pass settings
            Plugin = AndroidPluginUtility.CreateJavaInstance(Native.kClassName);
            Plugin.Call(Native.Method.kSetInternetReachabilityChangeListener, new InternetReachabilityChangeProxyListener(InvokeOnInternetConnectivityChange));
            Plugin.Call(Native.Method.kSetHostReachabilityChangeListener, new InternetReachabilityChangeProxyListener(InvokeOnHostReachabilityChange));
        }

        #endregion

        #region Base implemenation

        public override void StartNotifier()
        {
            Plugin.Call(Native.Method.kStart);//TODO pass details
        }

        public override void StopNotifier()
        {
            Plugin.Call(Native.Method.kEnd);
        }

        #endregion
    }
}
#endif