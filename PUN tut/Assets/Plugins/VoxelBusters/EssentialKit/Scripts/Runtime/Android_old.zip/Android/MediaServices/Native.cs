﻿#if UNITY_ANDROID
using System;

namespace VoxelBusters.EssentialKit.MediaServicesCore.Android
{
    public static class Native
    {
        internal const string kBasePackage                      = "com.voxelbusters.nativeplugins.v2.features.mediaservices";
        internal const string kClassName                        = kBasePackage + "." + "MediaServices";
        internal const string kRequestGalleryAccessListener     = kBasePackage + "." + "IRequestGalleryAccessListener";
        internal const string kGetGalleryAccessStatusListener   = kBasePackage + "." + "IGetGalleryAccessStatusListener";
        internal const string kRequestCameraAccessListener      = kBasePackage + "." + "IRequestCameraAccessListener";
        internal const string kGetCameraAccessStatusListener    = kBasePackage + "." + "IGetCameraAccessStatusListener";

        #region Nested classes

        internal class Method
        {
            internal static string kRequestGalleryAccess        = "requestGalleryAccess";
            internal static string kRequestCameraAccess         = "requestCameraAccess";
            internal static string kSelectPhotoFromGallery      = "selectPhotoFromGallery";
            internal static string kCanSelectPhotoFromGallery   = "canSelectPhotoFromGallery";
            internal static string kCanCapturePhotoFromCamera   = "canCapturePhotoFromCamera";
            internal static string kCapturePhotoFromCamera      = "capturePhotoFromCamera";
            internal static string kCanSaveImageToGallery       = "canSaveImageToGallery";
            internal static string kSaveImageToGallery          = "saveImageToGallery";
        }

        #endregion
    }
}
#endif