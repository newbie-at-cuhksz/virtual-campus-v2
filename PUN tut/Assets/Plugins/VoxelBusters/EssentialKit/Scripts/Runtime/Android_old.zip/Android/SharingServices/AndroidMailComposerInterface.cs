﻿#if UNITY_ANDROID
using UnityEngine;
using VoxelBusters.CoreLibrary;

namespace VoxelBusters.EssentialKit.SharingServicesCore.Android
{
    internal partial class AndroidMailComposerInterface : NativeMailComposerBase
    {
        #region  Properties

        private AndroidJavaObject Plugin
        {
            get;
            set;
        }

        #endregion

        #region Constructors

        public AndroidMailComposerInterface()
        {
            Plugin = AndroidPluginUtility.CreateJavaInstance(Native.kClassName);
        }

        #endregion

        #region Static methods

        public static bool CanSendMail()
        {
            using (AndroidJavaClass javaClass = AndroidPluginUtility.CreateJavaClass(Native.kClassName))
            {
                return javaClass.CallStatic<bool>(Native.Method.kCanSendMail, AndroidPluginUtility.GetContext());
            }
        }

        #endregion

        #region Base class overrides

        public override void AddAttachmentData(byte[] data, string mimeType, string fileName)
        {
            Plugin.Call(Native.Method.kAddAttachmentData, data, mimeType, fileName);
        }

        public override void AddScreenshot(string fileName)
        {
            string filePath = TextureExtensions.TakeScreenshot(fileName);
            Plugin.Call(Native.Method.kAddFileAtPathAsync, filePath, MimeType.kPNGImage);
        }

        public override void SetBccRecipients(params string[] values)
        {
            Plugin.Call(Native.Method.kSetBcc, (object)values);
        }

        public override void SetBody(string value, bool isHtml)
        {
            Plugin.Call(Native.Method.kSetMessage, value, isHtml);
        }

        public override void SetCcRecipients(params string[] values)
        {
            Plugin.Call(Native.Method.kSetCcRecipients, (object)values);
        }

        public override void SetSubject(string value)
        {
            Plugin.Call(Native.Method.kSetTitle, value);
        }

        public override void SetToRecipients(params string[] values)
        {
            Plugin.Call(Native.Method.kSetToRecipients, (object)values);
        }

        public override void Show()
        {
            Plugin.Call(Native.Method.kShow, new MailComposerProxyListener(InvokeOnClose));
        }

        #endregion
    }
}
#endif