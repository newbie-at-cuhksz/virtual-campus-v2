﻿#if UNITY_ANDROID

namespace VoxelBusters.EssentialKit.NetworkServicesCore.Android
{
    using Internal;

    internal partial class AndroidNetworkServicesInterface : NativeNetworkServicesInterfaceBase
    {
        #region Platform native Info

        private class Native
        {
            #region Fields

            internal const string kPackage                                  = "com.voxelbusters.nativeplugins.v2.features.networkservices";
            internal const string kClassName                                = kPackage + "." + "NetworkConnectivityHandler";
            internal const string kInternetReachabilityChangeProxyListener  = kPackage + "." + "INetworkServices$IInternetReachabilityChangeListener";
            internal const string kHostReachabilityChangeProxyListener      = kPackage + "." + "INetworkServices$IHostReachabilityChangeListener";


            #endregion

            #region Nested types

            internal class Method
            {
                internal const string kStart                                    = "startNotifier";
                internal const string kEnd                                      = "endNotifier";
                internal const string kSetInternetReachabilityChangeListener    = "setInternetReachabilityChangeListener";
                internal const string kSetHostReachabilityChangeListener        = "setHostReachabilityChangeListener";
            }

            #endregion
        }

        #endregion

        #region Proxy listeners

        internal class InternetReachabilityChangeProxyListener : NativeProxy<InternetConnectivityChangeInternalCallback>
        {
            #region Constructors

            public InternetReachabilityChangeProxyListener(InternetConnectivityChangeInternalCallback callback) : base(callback, Native.kInternetReachabilityChangeProxyListener)
            { 
            }

            #endregion

            #region Callbacks

            private void onChange(bool isConnected)
            {
                if (m_callback != null)
                {
                    DispatchOnMainThread(() => m_callback(isConnected));
                }
            }

            #endregion
        }

        internal class HostReachabilityChangeProxyListener : NativeProxy<HostReachabilityChangeInternalCallback>
        {
            #region Constructors

            public HostReachabilityChangeProxyListener(HostReachabilityChangeInternalCallback callback) : base(callback, Native.kHostReachabilityChangeProxyListener)
            {
            }

            #endregion

            #region Callbacks

            private void onChange(bool isConnected)
            {
                if (m_callback != null)
                {
                    DispatchOnMainThread(() => m_callback(isConnected));
                }
            }

            #endregion
        }



        #endregion

    }
}
#endif