﻿#if UNITY_ANDROID
using System;

namespace VoxelBusters.EssentialKit.GameServicesCore.Android
{
    public static class Native
    {
        internal const string kBasePackage                  = "com.voxelbusters.nativeplugins.v2.features.gameservices";

        #region Nested classes

        internal class Common
        {
            internal const string kViewClosedListener       = kBasePackage + "." + "common" + "." + "IViewClosedListener";
        }

        internal class Leaderboard
        {
            #region Constant fields
            internal const string kPackageName                          = kBasePackage + "." + "leaderboards";
            internal const string kClassName                            = kPackageName + "." + "Leaderboard";
            internal const string kLoadLeaderboardsListenerInterface    = kPackageName + "." + "ILoadLeaderboardsListener";

            #endregion

            #region Nested types

            internal class Method
            {
                internal const string kGetId                    = "getId";
                internal const string kLoadLeaderboards         = "loadLeaderboards";
                internal const string kGetTitle                 = "getTitle";
                internal const string kGetPlayerScope           = "getPlayerScope";
                internal const string kSetPlayerScope           = "setPlayerScope";
                internal const string kGetTimeScope             = "getTimeScope";
                internal const string kSetTimeScope             = "setTimeScope";
                internal const string kGetLocalPlayerScore      = "getLocalPlayerScope";
                internal const string kLoadTopScores            = "loadTopScores";
                internal const string kShowLeaderboardView      = "showLeaderboardView";
                internal const string kLoadPlayerCenteredScores = "loadPlayerCenteredScores";
                internal const string kLoadMoreScores           = "loadMoreScores";
                internal const string kLoadPreviewImage         = "loadPreviewImage";
            }

            #endregion
        }

        internal class Achievement
        {
            #region Constant fields
            internal const string kPackageName                          = kBasePackage + "." + "achievements";
            internal const string kClassName                            = kPackageName + "." + "Achievement";
            internal const string kReportProgressListenerInterface      = kPackageName + "." + "IReportProgressListener";
            internal const string kLoadAchievementsListenerInterface    = kPackageName + "." + "ILoadAchievementsListener";

            #endregion

            #region Nested types

            internal class Method
            {
                internal const string kGetId                    = "getId";
                internal const string kLoadAchievements         = "loadAchievements";
                internal const string kReportProgress           = "reportProgress";
                internal const string kGetPercentageCompleted   = "getPercentageCompleted";
                internal const string kSetPercentageCompleted   = "setPercentageCompleted";
                internal const string kGetIsCompleted           = "isCompleted";
                internal const string kGetLastReportedDate      = "getLastReportedDate";
                internal static string kShowAchievementView     = "showAchievementView";
            }

            #endregion
        }

        internal class AchievementDescription
        {
            #region Constant fields

            internal const string kPackageName                                      = kBasePackage + "." + "achievements";
            internal const string kClassName                                        = kPackageName + "." + "AchievementDescription";
            internal const string kLoadAchievementsDescriptionsListenerInterface    = kPackageName + "." + "ILoadAchievementDescriptionsListener";


            #endregion

            #region Nested types

            internal class Method
            {
                internal const string kGetId                            = "getId";
                internal const string kLoadAchievementDescriptions      = "loadAchievementDescriptions";
                internal const string kGetTitle                         = "getTitle";
                internal const string kGetUnachievedDescription         = "getUnachievedDescrition";
                internal const string kGetAchievedDescription           = "getAchievedDescription";
                internal const string kGetMaximumPoints                 = "getMaximumPoints";
                internal const string kIsHidden                         = "isHidden";
                internal const string kIsReplayable                     = "isReplayable";
                internal const string kLoadIncompleteAchievementImage   = "loadIncompleteAchievementImage";
                internal const string kLoadAchievementImage             = "loadAchievementImage";

            }

            #endregion
        }

        internal class Score
        {
            #region Constant fields

            internal const string kPackageName                      = kBasePackage + "." + "scores";
            internal const string kClassName                        = kPackageName + "." + "Score";
            internal const string kReportScoreListenerInterface     = kPackageName + "." + "IReportScoreListener";

            #endregion

            #region Nested types

            internal class Method
            {
                internal const string kGetId                = "getLeaderboardId";
                internal const string kGetPlayer            = "getPlayer";
                internal const string kGetRank              = "getRank";
                internal const string kGetValue             = "getValue";
                internal const string kSetValue             = "setValue";
                internal const string kGetLastReportedDate  = "getLastReportedDate";
                internal const string kReportScore          = "reportScore";
            }

            #endregion
        }

        internal class Player
        {
            #region Constant fields

            internal const string kPackageName          = kBasePackage + "." + "players";
            internal const string kClassName            = kPackageName + "." + "Player";
            internal const string kLoadPlayersListener  = kPackageName + "." + "ILoadPlayersListener";

            #endregion

            #region Nested types

            internal class Method
            {
                internal static string kGetId               = "getId";
                internal static string kGetAlias            = "getAlias";
                internal static string kGetDisplayName      = "getDisplayName";
                internal static string kLoadPlayers         = "loadPlayers";
                internal static string kLoadPreviewImage    = "loadPreviewImage";
                internal static string kGetLocalPlayer      = "getLocalPlayer";
            }

            #endregion
        }

        internal class LocalPlayer
        {
            internal const string kPackageName                  = kBasePackage + "." + "players";
            internal const string kClassName                    = kPackageName + "." + "LocalPlayer";
            internal const string kAuthChangeListenerInterface  = kPackageName + "." + "IAuthChangeListener";

            internal class Method
            {
                internal const string kAuthenticate         = "authenticate";
                internal const string kGetLocalPlayer       = "getLocalPlayer";
                internal const string kIsUnderAge           = "isUnderAge";
                internal const string kIsAuthenticated      = "isAuthenticated";
            }

        }

        #endregion
    }
}
#endif