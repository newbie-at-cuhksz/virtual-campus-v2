﻿#if UNITY_ANDROID
using System;

namespace VoxelBusters.EssentialKit.CloudServicesCore.Android
{
    using Internal;
    using UnityEngine;

    internal class UserChangeProxyListener : NativeProxy<UserChangeInternalCallback>
    {
        #region Constructors

        public UserChangeProxyListener(UserChangeInternalCallback callback) : base(callback, CloudServicesInterface.Native.kUserChangeListenerInterface)
        {
        }

        #endregion

        #region Callbacks

        private void onUserChange(ICloudUser user, string error)
        {
            if (m_callback != null)
            {
                Action action = () => m_callback(user, error);
                DispatchOnMainThread(action);
            }
        }

        public override AndroidJavaObject Invoke(string methodName, AndroidJavaObject[] javaArgs)
        {
            if (methodName == "onUserChange")
            {

                AndroidJavaObject user  = javaArgs[0];
                string error            = javaArgs[1].GetString();

                onUserChange(new CloudUser(user), error);
                return null;
            }
            else
            {
                return base.Invoke(methodName, javaArgs);
            }
        }

        #endregion
    }
}
#endif