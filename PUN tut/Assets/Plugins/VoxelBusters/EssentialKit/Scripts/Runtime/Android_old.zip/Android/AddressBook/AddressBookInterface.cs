﻿#if UNITY_ANDROID
using UnityEngine;

namespace VoxelBusters.EssentialKit.AddressBookCore.Android
{
    using Internal;
    internal partial class AddressBookInterface : NativeAddressBookInterfaceBase
    {
        #region Properties

        private AndroidJavaObject Plugin
        {
            get;
            set;
        }

        #endregion

        #region Constructors

        static AddressBookInterface()
        {
            using (AndroidJavaClass javaClass = AndroidPluginUtility.CreateJavaClass(Native.kClassName))
            {
                javaClass.CallStatic(Native.Method.kInitialise, "USAGE DESCRIPTION HERE");//TODO Set the description here
            }
        }

        public AddressBookInterface()
        {
            Plugin = AndroidPluginUtility.CreateJavaInstance(Native.kClassName);
        }

        #endregion

        #region IAddressBookNativeInterface implementation

        public override void ReadContacts(ReadContactsInternalCallback callback)
        {
            Plugin.Call(Native.Method.kReadContacts, new ReadContactsProxyListener(callback));
        }

        public override void RequestAccess(RequestAccessInternalCallback callback)
        {
            Plugin.Call(Native.Method.kRequestPermission, new PermissionRequestProxyListener(callback));
        }

        public override AddressBookAccessStatus GetAccessStatus()
        {
            bool _accessGranted = Plugin.Call<bool>(Native.Method.kIsAuthorized);

            return _accessGranted ? AddressBookAccessStatus.Authorized : AddressBookAccessStatus.Denied;
        }

        #endregion
    }
}
#endif