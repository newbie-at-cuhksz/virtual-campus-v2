﻿#if UNITY_ANDROID
using System;
using UnityEngine;
using VoxelBusters.EssentialKit.Internal;
using VoxelBusters.EssentialKit.MediaServicesCore;

namespace VoxelBusters.EssentialKit.MediaServicesCore.Android
{
    internal class RequestCameraAccessProxyListener : NativeProxy<RequestCameraAccessInternalCallback>
    {
        #region Constructors

        public RequestCameraAccessProxyListener(RequestCameraAccessInternalCallback callback) : base(callback, Native.kRequestCameraAccessListener)
        {
        }

        #endregion

        #region Callbacks

        private void onRequestAccessComplete(CameraAccessStatus status, string error)
        {
            if (m_callback != null)
            {
                Action action = () => m_callback(status, error);
                DispatchOnMainThread(action);
            }

        }

        public override AndroidJavaObject Invoke(string methodName, AndroidJavaObject[] javaArgs)
        {
            if (methodName == "onRequestAccessComplete")
            {
                AndroidCameraAccessStatus status = javaArgs[0].GetEnum<AndroidCameraAccessStatus>();
                string error = javaArgs[1].GetString();

                onRequestAccessComplete(status.Convert(), error);
                return null;
            }
            else
            {
                return base.Invoke(methodName, javaArgs);
            }
        }

        #endregion
    }
}
#endif