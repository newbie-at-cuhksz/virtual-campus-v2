﻿#if UNITY_ANDROID
using System;

namespace VoxelBusters.EssentialKit.GameServicesCore.Android
{
    using Internal;

    internal class ViewClosedProxyListener : NativeProxy<ViewClosedInternalCallback>
    {
        #region Constructors

        public ViewClosedProxyListener(ViewClosedInternalCallback callback) : base(callback, Native.Common.kViewClosedListener)
        {
        }

        #endregion

        #region Callbacks

        private void onViewClosed(string error)
        {
            if (m_callback != null)
            {
                Action action = () => m_callback(error);
                DispatchOnMainThread(action);
            }
        }

        #endregion
    }
}
#endif