﻿#if UNITY_ANDROID
using UnityEngine;
using VoxelBusters.EssentialKit.Internal;
using VoxelBusters.NativePlugins.Internal;

namespace VoxelBusters.EssentialKit.CloudServicesCore.Android
{
    internal sealed class CloudUser : CloudUserBase
    {
        #region Fields

        private     string                      m_userId;
        private     CloudUserAccountStatus      m_status;

        #endregion

        #region Constructors

        public CloudUser(AndroidJavaObject user)
        {
            // set properties
            m_userId        = user.Call<string>("id");
            m_status = Convert(user.GetEnum<AndroidCloudUserAccountStatus>());
        }

        #endregion

        #region Helpers

        internal static CloudUserAccountStatus Convert(AndroidCloudUserAccountStatus status)
        {
            switch (status)
            {
                case AndroidCloudUserAccountStatus.CouldNotDetermine:
                    return CloudUserAccountStatus.CouldNotDetermine;

                case AndroidCloudUserAccountStatus.Available:
                    return CloudUserAccountStatus.Available;

                case AndroidCloudUserAccountStatus.Restricted:
                    return CloudUserAccountStatus.Restricted;

                case AndroidCloudUserAccountStatus.NoAccount:
                    return CloudUserAccountStatus.NoAccount;

                default:
                    throw ExceptionFactory.SwitchCaseNotImplementedException(status);
            }
        }

        #endregion

        #region Data types

        internal enum AndroidCloudUserAccountStatus
        {
            CouldNotDetermine = 0,

            Available = 1,

            Restricted = 2,

            NoAccount = 3,
        }

        #endregion
    }
}
#endif