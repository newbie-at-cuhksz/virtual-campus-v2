﻿#if UNITY_ANDROID
using UnityEngine;
using VoxelBusters.CoreLibrary;
using VoxelBusters.EssentialKit.Internal;

namespace VoxelBusters.EssentialKit.MediaServicesCore.Android
{
    internal class MediaServicesInterface : NativeMediaServicesInterfaceBase
    {
        #region Properties

        private AndroidJavaObject Plugin
        {
            get;
            set;
        }

        #endregion

        #region Constructors

        public MediaServicesInterface()
        {
            Plugin = AndroidPluginUtility.CreateJavaInstance(Native.kClassName);
        }

        #endregion

        #region Base class methods

        public override void RequestGalleryAccess(RequestGalleryAccessInternalCallback callback)
        {
            Plugin.Call(Native.Method.kRequestGalleryAccess, new RequestGalleryAccessProxyListener(callback)); 
        }

        public override GalleryAccessStatus GetGalleryAccessStatus()
        {
            AndroidGalleryAccessStatus status = Plugin.Call<AndroidJavaObject>(Native.Method.kRequestGalleryAccess).GetEnum<AndroidGalleryAccessStatus>();
            return status.Convert();
        }

        public override void RequestCameraAccess(RequestCameraAccessInternalCallback callback)
        {
            Plugin.Call(Native.Method.kRequestGalleryAccess, new RequestCameraAccessProxyListener(callback));
        }

        public override CameraAccessStatus GetCameraAccessStatus()
        {
            AndroidCameraAccessStatus status = Plugin.Call<AndroidJavaObject>(Native.Method.kRequestCameraAccess).GetEnum<AndroidCameraAccessStatus>();
            return status.Convert();
        }

        public override bool CanSelectImageFromGallery()
        {
            return Plugin.Call<bool>(Native.Method.kCanSelectPhotoFromGallery);
        }

        public override void SelectImageFromGallery(bool canEdit, SelectImageInternalCallback callback)
        {
            Plugin.Call(Native.Method.kSelectPhotoFromGallery, canEdit, new SelectPhotoProxyListener(callback));
        }

        public override bool CanCaptureImageFromCamera()
        {
            return Plugin.Call<bool>(Native.Method.kCanCapturePhotoFromCamera);
        }

        public override void CaptureImageFromCamera(bool canEdit, SelectImageInternalCallback callback)
        {
            Plugin.Call(Native.Method.kCapturePhotoFromCamera, canEdit, new SelectPhotoProxyListener(callback));
        }

        public override bool CanSaveImageToGallery()
        {
            return Plugin.Call<bool>(Native.Method.kCanSaveImageToGallery);
        }

        public override void SaveImageToGallery(string albumName, Texture2D image, SaveImageToGalleryInternalCallback callback)
        {
            string mimeType;
            byte[] data = image.Encode(out mimeType);
            Plugin.Call(Native.Method.kSaveImageToGallery, data, mimeType, new SaveImageToGalleryProxyListener(callback));
        }

        #endregion
    }
}
#endif