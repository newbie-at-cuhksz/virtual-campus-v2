﻿#if UNITY_ANDROID
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using VoxelBusters.EssentialKit.Internal;

namespace VoxelBusters.EssentialKit.GameServicesCore.Android
{
    internal class LocalPlayer : Player, ILocalPlayer
    {
        #region Static fields

        private static LocalPlayer                  s_localPlayer   = null;
        private static AuthChangeInternalCallback   s_authCallback  = null;

        #endregion

        #region Properties

        private AndroidJavaObject Plugin
        {
            get;
            set;
        }

        #endregion

        #region Constructors

        private LocalPlayer(AndroidJavaObject nativeObject):base(nativeObject)
        {
            Plugin = nativeObject;
        }

        #endregion

        #region Static methods

        public static LocalPlayer GetLocalPlayer()
        {
            if (s_localPlayer == null)
            {
                using (AndroidJavaClass javaClass = AndroidPluginUtility.CreateJavaClass(Native.LocalPlayer.kClassName))
                {
                    AndroidJavaObject nativeObject = javaClass.CallStatic<AndroidJavaObject>(Native.LocalPlayer.Method.kGetLocalPlayer, AndroidPluginUtility.GetContext());
                    s_localPlayer = new LocalPlayer(nativeObject);
                }
            }

            return s_localPlayer;
        }

        public static void Authenticate()
        {
            GetLocalPlayer().Plugin.Call(Native.LocalPlayer.Method.kAuthenticate, new AuthChangeProxyListener(s_authCallback));
        }

        public static void SetAuthChangeCallback(AuthChangeInternalCallback callback)
        {
            s_authCallback = callback;
        }

        #endregion

        #region ILocalPlayer implementation

        public bool IsAuthenticated
        {
            get
            {
                return Plugin.Call<bool>(Native.LocalPlayer.Method.kIsAuthenticated);
            }
        }

        public bool IsUnderAge
        {
            get
            {
                return Plugin.Call<bool>(Native.LocalPlayer.Method.kIsUnderAge);
            }
        }

        #endregion
    }
}
#endif