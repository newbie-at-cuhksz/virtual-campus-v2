﻿#if UNITY_ANDROID
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using VoxelBusters.EssentialKit.Internal;

namespace VoxelBusters.EssentialKit.GameServicesCore.Android
{
    internal class AchievementDescription : AchievementDescriptionBase
    {
        #region Properties

        private AndroidJavaObject Plugin
        {
            get;
            set;
        }

        #endregion

        #region Constructors

        public AchievementDescription(AndroidJavaObject nativeObject) : base(nativeObject.Get<string>("getId"))
        {
            Plugin = nativeObject;
        }

        #endregion

        #region Static methods

        public static void LoadAchievementDescriptions(LoadAchievementDescriptionsInternalCallback callback)
        {
            using (AndroidJavaClass javaClass = AndroidPluginUtility.CreateJavaClass(Native.Achievement.kClassName))
            {
                javaClass.CallStatic<bool>(Native.AchievementDescription.Method.kLoadAchievementDescriptions, AndroidPluginUtility.GetContext(), new LoadAchievementDescriptionsProxyListener(callback));
            }
        }

        #endregion

        #region Base class methods

        protected override string GetTitleInternal()
        {
            return Plugin.Call<string>(Native.AchievementDescription.Method.kGetTitle);
        }

        protected override string GetUnachievedDescriptionInternal()
        {
            return Plugin.Call<string>(Native.AchievementDescription.Method.kGetUnachievedDescription);
        }

        protected override string GetAchievedDescriptionInternal()
        {
            return Plugin.Call<string>(Native.AchievementDescription.Method.kGetAchievedDescription);
        }

        protected override long GetMaximumPointsInternal()
        {
            return Plugin.Call<long>(Native.AchievementDescription.Method.kGetMaximumPoints);
        }

        protected override bool GetIsHiddenInternal()
        {
            return Plugin.Call<bool>(Native.AchievementDescription.Method.kIsHidden);
        }

        protected override bool GetIsReplayableInternal()
        {
            return Plugin.Call<bool>(Native.AchievementDescription.Method.kIsReplayable);//TODO
        }

        protected override void LoadIncompleteAchievementImageInternal(LoadImageInternalCallback callback)
        {
            Plugin.Call(Native.AchievementDescription.Method.kLoadIncompleteAchievementImage, new LoadImageProxyListener(callback));
        }

        protected override void LoadImageInternal(LoadImageInternalCallback callback)
        {
            Plugin.Call<string>(Native.AchievementDescription.Method.kLoadAchievementImage, new LoadImageProxyListener(callback));
        }

        #endregion
    }
}

#endif