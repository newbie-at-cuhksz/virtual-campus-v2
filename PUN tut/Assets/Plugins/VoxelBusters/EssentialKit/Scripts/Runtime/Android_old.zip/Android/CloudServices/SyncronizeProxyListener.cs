﻿#if UNITY_ANDROID
using System;

namespace VoxelBusters.EssentialKit.CloudServicesCore.Android
{
    using Internal;
    internal class SyncronizeProxyListener : NativeProxy<SynchronizeInternalCallback>
    {
        #region Constructors

        public SyncronizeProxyListener(SynchronizeInternalCallback callback) : base(callback, CloudServicesInterface.Native.kSyncronizeListenerInterface)
        {
        }

        #endregion

        #region Callbacks

        private void onSyncronizeComplete(bool success, string error)
        {
            if (m_callback != null)
            {
                Action action = () => m_callback(success, error);
                DispatchOnMainThread(action);
            }
        }

        #endregion
    }
}
#endif