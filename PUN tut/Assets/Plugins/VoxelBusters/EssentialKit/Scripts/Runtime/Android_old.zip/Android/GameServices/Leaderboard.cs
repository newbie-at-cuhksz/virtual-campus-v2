﻿#if UNITY_ANDROID
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using VoxelBusters.EssentialKit.Internal;
using VoxelBusters.NativePlugins.Internal;

namespace VoxelBusters.EssentialKit.GameServicesCore.Android
{
    internal class Leaderboard : LeaderboardBase
    {
        #region Properties

        private AndroidJavaObject Plugin
        {
            get;
            set;
        }

        #endregion

        #region Constructors

        public Leaderboard(string id, string platformId) : base(id, platformId)
        {
            Plugin = AndroidPluginUtility.CreateJavaInstance(Native.Leaderboard.kClassName, true, platformId);
        }

        public Leaderboard(AndroidJavaObject nativeObject) : base(nativeObject.Get<string>("getId"))
        {
            Plugin = nativeObject;
        }

        #endregion

        #region Static methods

        public static void LoadLeaderboards(LoadLeaderboardsInternalCallback callback)
        {
            using (AndroidJavaClass javaClass = AndroidPluginUtility.CreateJavaClass(Native.Leaderboard.kClassName))
            {
                javaClass.CallStatic<bool>(Native.Leaderboard.Method.kLoadLeaderboards, AndroidPluginUtility.GetContext(), new LoadLeaderboardsProxyListener(callback));
            }
        }

        public static void ShowLeaderboardView(string leaderboardPlatformId, LeaderboardTimeScope timescope, ViewClosedInternalCallback callback)
        {
            using (AndroidJavaClass javaClass = AndroidPluginUtility.CreateJavaClass(Native.Leaderboard.kClassName))
            {
                javaClass.CallStatic<bool>(Native.Leaderboard.Method.kShowLeaderboardView, leaderboardPlatformId, (int)timescope, new ViewClosedProxyListener(callback));
            }
        }

        #endregion

        #region Base class methods

        protected override string GetTitleInternal()
        {
            return Plugin.Call<string>(Native.Leaderboard.Method.kGetTitle);
        }

        protected override LeaderboardPlayerScope GetPlayerScopeInternal()
        {
            AndroidJavaObject androidJavaObject = Plugin.Call<AndroidJavaObject>(Native.Leaderboard.Method.kGetPlayerScope);
            AndroidLeaderboardPlayerScope scope = androidJavaObject.GetEnum<AndroidLeaderboardPlayerScope>();
            return Convert(scope);
        }

        protected override void SetPlayerScopeInternal(LeaderboardPlayerScope value)
        {
            AndroidLeaderboardPlayerScope scope     = Convert(value);
            Plugin.Call(Native.Leaderboard.Method.kSetPlayerScope, (int)scope);
        }

        protected override LeaderboardTimeScope GetTimeScopeInternal()
        {
            AndroidJavaObject androidJavaObject = Plugin.Call<AndroidJavaObject>(Native.Leaderboard.Method.kGetTimeScope);
            AndroidLeaderboardTimeScope scope = androidJavaObject.GetEnum<AndroidLeaderboardTimeScope>();
            return Convert(scope);
        }
        
        protected override void SetTimeScopeInternal(LeaderboardTimeScope value)
        {
            AndroidLeaderboardTimeScope scope = Convert(value);
            Plugin.Call(Native.Leaderboard.Method.kSetTimeScope, (int)scope);
        }

        protected override IScore GetLocalPlayerScoreInternal()
        {
            AndroidJavaObject score = Plugin.Call<AndroidJavaObject>(Native.Leaderboard.Method.kGetLocalPlayerScore);
            if(score != null)
            {
                return new Score(score);
            }

            return null;
        }

        protected override void LoadTopScoresInternal(LoadScoresInternalCallback callback)
        {
            Plugin.Call(Native.Leaderboard.Method.kLoadTopScores, LoadScoresQuerySize, new LoadScoresProxyListener(callback));
        }

        protected override void LoadPlayerCenteredScoresInternal(LoadScoresInternalCallback callback)
        {
            Plugin.Call(Native.Leaderboard.Method.kLoadPlayerCenteredScores, LoadScoresQuerySize, new LoadScoresProxyListener(callback));
        }

        protected override void LoadNextInternal(LoadScoresInternalCallback callback)
        {
            Plugin.Call(Native.Leaderboard.Method.kLoadMoreScores, LoadScoresQuerySize, 1, new LoadScoresProxyListener(callback));
        }

        protected override void LoadPreviousInternal(LoadScoresInternalCallback callback)
        {
            Plugin.Call(Native.Leaderboard.Method.kLoadMoreScores, LoadScoresQuerySize, -1, new LoadScoresProxyListener(callback));
        }

        protected override void LoadImageInternal(LoadImageInternalCallback callback)
        {
            Plugin.Call(Native.Leaderboard.Method.kLoadPreviewImage, new LoadImageProxyListener(callback));
        }

       
        #endregion

        #region Helpers

        private LeaderboardPlayerScope Convert(AndroidLeaderboardPlayerScope scope)
        {
            switch (scope)
            {
                case AndroidLeaderboardPlayerScope.Global:
                    return LeaderboardPlayerScope.Global;

                default:
                    throw ExceptionFactory.SwitchCaseNotImplementedException(scope);
            }
        }

        private AndroidLeaderboardPlayerScope Convert(LeaderboardPlayerScope scope)
        {
            switch (scope)
            {
                case LeaderboardPlayerScope.Global:
                    return AndroidLeaderboardPlayerScope.Global;
                case LeaderboardPlayerScope.FriendsOnly:
                    ExceptionFactory.NotSupportedException();//Social scope is deprecated on Android
                    return AndroidLeaderboardPlayerScope.Global;

                default:
                    throw ExceptionFactory.SwitchCaseNotImplementedException(scope);
            }
        }

        private LeaderboardTimeScope Convert(AndroidLeaderboardTimeScope scope)
        {
            switch (scope)
            {
                case AndroidLeaderboardTimeScope.Daily:
                    return LeaderboardTimeScope.Today;
                case AndroidLeaderboardTimeScope.Weekly:
                    return LeaderboardTimeScope.Week;
                case AndroidLeaderboardTimeScope.AllTime:
                    return LeaderboardTimeScope.AllTime;

                default:
                    throw ExceptionFactory.SwitchCaseNotImplementedException(scope);
            }
        }

        private AndroidLeaderboardTimeScope Convert(LeaderboardTimeScope scope)
        {
            switch (scope)
            {
                case LeaderboardTimeScope.Today:
                    return AndroidLeaderboardTimeScope.Daily;
                case LeaderboardTimeScope.Week:
                    return AndroidLeaderboardTimeScope.Weekly;
                case LeaderboardTimeScope.AllTime:
                    return AndroidLeaderboardTimeScope.AllTime;

                default:
                    throw ExceptionFactory.SwitchCaseNotImplementedException(scope);
            }
        }

        #endregion

        #region Nested data types

        internal enum AndroidLeaderboardPlayerScope
        {
            Global
        }

        internal enum AndroidLeaderboardTimeScope
        {
            Daily,
            Weekly,
            AllTime
        }

        #endregion
    }
}
#endif