﻿#if UNITY_ANDROID
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

namespace VoxelBusters.EssentialKit.AddressBookCore.Android
{
    using Internal;
    using VoxelBusters.CoreLibrary;

    internal class AddressBookContact : AddressBookContactBase
    {
        #region Fields

        private AndroidJavaObject   m_profilePicture;

        private string              m_firstName;

        private string              m_middleName;

        private string              m_lastName;

        private string[]            m_phoneNumbers;

        private string[]            m_emailAddresses;

        #endregion

        #region Internal methods

        internal static AddressBookContact FromNativeObject(AndroidJavaObject nativeObject)
        {
            AddressBookContact contact = new AddressBookContact();
            contact.m_firstName = nativeObject.Call<string>("givenName");
            contact.m_lastName = nativeObject.Call<string>("familyName");

            contact.m_phoneNumbers = nativeObject.Call<string[]>("phoneNumbers");
            contact.m_emailAddresses = nativeObject.Call<string[]>("emailAddresses");
            contact.SetProfilePicture(nativeObject.Call<AndroidJavaObject>("profilePicture"));

            return contact;
        }

        #endregion

        #region Internal methods

        internal void SetProfilePicture(AndroidJavaObject javaObject)
        {
            m_profilePicture = javaObject;
        }

        #endregion

        #region Base implementation

        protected override string GetFirstNameInternal()
        {
            return m_firstName;
        }

        protected override string GetMiddleNameInternal()
        {
            return m_middleName;
        }

        protected override string GetLastNameInternal()
        {
            return m_lastName;
        }

        protected override string[] GetPhoneNumbersInternal()
        {
            return m_phoneNumbers;
        }

        protected override string[] GetEmailAddressesInternal()
        {
            return m_emailAddresses;
        }

        protected override void LoadImageInternal(LoadImageInternalCallback callback)
        {
            if (callback == null)
                return;

            if (m_profilePicture != null)
            {
                m_profilePicture.Call("load", AndroidPluginUtility.GetContext(), new LoadImageProxyListener(callback));
            }
            else
            {
                callback(AddressBook.DefaultImage.Encode(), null);
            }
        }

        #endregion
    }
}
#endif
