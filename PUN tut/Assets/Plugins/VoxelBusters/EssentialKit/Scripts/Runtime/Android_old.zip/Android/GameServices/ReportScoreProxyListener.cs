﻿#if UNITY_ANDROID
using System;

namespace VoxelBusters.EssentialKit.GameServicesCore.Android
{
    using Internal;

    internal class ReportScoreProxyListener : NativeProxy<ReportScoreInternalCallback>
    {
        #region Constructors

        public ReportScoreProxyListener(ReportScoreInternalCallback callback) : base(callback, Native.Score.kReportScoreListenerInterface)
        {
        }

        #endregion

        #region Callbacks

        private void onReportScoreComplete(string error)
        {
            if (m_callback != null)
            {
                Action action = () => m_callback(error);
                DispatchOnMainThread(action);
            }
        }

        #endregion
    }
}
#endif