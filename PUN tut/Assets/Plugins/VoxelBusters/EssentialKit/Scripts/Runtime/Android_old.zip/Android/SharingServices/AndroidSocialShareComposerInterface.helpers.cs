﻿#if UNITY_ANDROID
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using VoxelBusters.EssentialKit.Internal;
using VoxelBusters.NativePlugins.Internal;

namespace VoxelBusters.EssentialKit.SharingServicesCore.Android
{
    internal partial class AndroidSocialShareComposerInterface : NativeSocialShareComposerBase
    {
        #region Native platform info

        private class Native
        {
            internal const string kPackage                          = "com.voxelbusters.nativeplugins.v2.features.sharing";
            internal const string kName                             = kPackage + "." + "SocialShareComposer";
            internal const string kShareComposerListenerInterface   = kPackage + "." + "ISharing$ISocialShareComposerListener";

            internal class Method
            {
                internal const string kIsComposerAvailable  = "isComposerAvailable";
                internal const string kAddAttachmentData    = "addAttachmentData";
                internal const string kAddFileAtPathAsync   = "addFileAtPathAsync";
                internal const string kSetMessage           = "setMessage";
                internal const string kSetURL               = "setUrl";
                internal const string kSetComposerType      = "setComposerType";
                internal const string kShow                 = "show";
            }
        }

        #endregion

        #region Proxy listeners

        internal class SocialShareComposerProxyListener : NativeProxy<SocialShareComposerClosedInternalCallback>
        {
            #region Constructors

            public SocialShareComposerProxyListener(SocialShareComposerClosedInternalCallback callback) : base(callback, Native.kShareComposerListenerInterface)
            {
            }

            #endregion

            #region Callbacks

            private void onAction(AndroidSocialShareComposerResultCode resultCode)
            {
                if (m_callback != null)
                {
                    DispatchOnMainThread(() => m_callback(Convert(resultCode), null));
                }
            }

            public override AndroidJavaObject Invoke(string methodName, AndroidJavaObject[] javaArgs)
            {
                if (methodName == "onAction")
                {
                    AndroidSocialShareComposerResultCode resultCode = (AndroidSocialShareComposerResultCode)javaArgs[0].Call<int>("ordinal");

                    onAction(resultCode);
                    return null;
                }
                else
                {
                    return base.Invoke(methodName, javaArgs);
                }
            }

            #endregion

            #region Helpers

            private SocialShareComposerResultCode Convert(AndroidSocialShareComposerResultCode resultCode)
            {
                switch (resultCode)
                {
                    case AndroidSocialShareComposerResultCode.Cancelled:
                        return SocialShareComposerResultCode.Cancelled;

                    case AndroidSocialShareComposerResultCode.Done:
                        return SocialShareComposerResultCode.Done;

                    case AndroidSocialShareComposerResultCode.Unknown:
                        return SocialShareComposerResultCode.Unknown;

                    default:
                        throw ExceptionFactory.SwitchCaseNotImplementedException(resultCode);
                }
            }

            #endregion
        }

        #endregion

        #region Data types

        internal enum AndroidSocialShareComposerResultCode
        {
            Cancelled,
            Done,
            Unknown
        }

        #endregion
    }
}
#endif