﻿#if UNITY_ANDROID
using VoxelBusters.EssentialKit.Internal;

namespace VoxelBusters.EssentialKit.WebViewCore.Android
{
    internal class JavaScriptResultProxyListener : NativeProxy<RunJavaScriptInternalCallback>
    {
        #region Constructors

        public JavaScriptResultProxyListener(RunJavaScriptInternalCallback callback) : base(callback, Native.kJavaScriptResultListener)
        {
        }

        #endregion

        #region Callbacks

        private void onResult(string result, string error)
        {
            if (m_callback != null)
            {
                DispatchOnMainThread(() => m_callback(result, error));
            }
        }

        #endregion
    }
}
#endif