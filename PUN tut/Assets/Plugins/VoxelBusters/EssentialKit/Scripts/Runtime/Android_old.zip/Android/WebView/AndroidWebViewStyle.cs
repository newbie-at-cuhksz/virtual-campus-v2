﻿namespace VoxelBusters.EssentialKit.WebViewCore.Android
{
    public enum AndroidWebViewStyle
    {
        Default,
        ShowCloseButton,
        Browser
    }
}