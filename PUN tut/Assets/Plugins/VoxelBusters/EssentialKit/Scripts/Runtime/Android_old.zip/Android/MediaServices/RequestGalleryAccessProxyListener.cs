﻿#if UNITY_ANDROID
using System;
using UnityEngine;
using VoxelBusters.EssentialKit.Internal;

namespace VoxelBusters.EssentialKit.MediaServicesCore.Android
{
    internal class RequestGalleryAccessProxyListener : NativeProxy<RequestGalleryAccessInternalCallback>
    {
        #region Constructors

        public RequestGalleryAccessProxyListener(RequestGalleryAccessInternalCallback callback) : base(callback, Native.kRequestGalleryAccessListener)
        {
        }

        #endregion

        #region Callbacks

        private void onRequestAccessComplete(GalleryAccessStatus status, string error)
        {
            if (m_callback != null)
            {
                Action action = () => m_callback(status, error);
                DispatchOnMainThread(action);
            }

        }

        public override AndroidJavaObject Invoke(string methodName, AndroidJavaObject[] javaArgs)
        {
            if (methodName == "onRequestAccessComplete")
            {
                AndroidGalleryAccessStatus  status      = javaArgs[0].GetEnum<AndroidGalleryAccessStatus>();
                string                      error       = javaArgs[1].GetString();

                onRequestAccessComplete(Utility.Convert(status), error);
                return null;
            }
            else
            {
                return base.Invoke(methodName, javaArgs);
            }
        }

        #endregion
    }
}
#endif