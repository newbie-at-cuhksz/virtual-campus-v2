﻿#if UNITY_ANDROID
using UnityEngine;

namespace VoxelBusters.EssentialKit.SharingServicesCore.Android
{
    using Internal;
    using VoxelBusters.NativePlugins.Internal;

    internal partial class MessageComposerInterface : NativeMessageComposerBase
    {
        #region Platform native info

        class Native
        {
            internal const string kPackage = "com.voxelbusters.nativeplugins.v2.features.sharing";
            internal const string kClassName = kPackage + "." + "MessageComposer";
            internal const string kMessageComposerListenerInterface = kPackage + "." + "ISharing$IMessageComposerListener";

            #region Nested types

            internal class Method
            {
                internal const string kCanSendText = "canSendText";
                internal const string kCanSendAttachments = "canSendAttachments";
                internal const string kCanSendSubject = "canSendSubject";
                internal const string kAddFileAtPathAsync = "addFileAtPathAsync";
                internal const string kAddAttachmentData = "addAttachmentData";
                internal const string kSetMessage = "setMessage";
                internal const string kSetTitle = "setTitle";
                internal const string kSetToRecipients = "setToRecipients";
                internal const string kShow = "show";
            }
            #endregion
        }

        #endregion

        #region Proxy listeners

        internal class MessageComposerProxyListener : NativeProxy<MessageComposerClosedInternalCallback>
        {
            #region Constructors

            public MessageComposerProxyListener(MessageComposerClosedInternalCallback callback) : base(callback, Native.kMessageComposerListenerInterface)
            { }

            #endregion

            #region Callbacks

            private void onAction(AndroidMessageComposerResultCode resultCode)
            {
                if (m_callback != null)
                {
                    DispatchOnMainThread(() => m_callback(Convert(resultCode), null));
                }
            }

            public override AndroidJavaObject Invoke(string methodName, AndroidJavaObject[] javaArgs)
            {
                if (methodName == "onAction")
                {
                    AndroidMessageComposerResultCode resultCode = (AndroidMessageComposerResultCode)javaArgs[0].Call<int>("ordinal");

                    onAction(resultCode);
                    return null;
                }
                else
                {
                    return base.Invoke(methodName, javaArgs);
                }
            }

            #endregion

            #region Helpers

            private MessageComposerResultCode Convert(AndroidMessageComposerResultCode resultCode)
            {
                switch (resultCode)
                {
                    case AndroidMessageComposerResultCode.Cancelled:
                        return MessageComposerResultCode.Cancelled;

                    case AndroidMessageComposerResultCode.Sent:
                        return MessageComposerResultCode.Sent;

                    case AndroidMessageComposerResultCode.Unknown:
                        return MessageComposerResultCode.Unknown;

                    default:
                        throw ExceptionFactory.SwitchCaseNotImplementedException(resultCode);
                }
            }

            #endregion
        }

        #endregion

        #region Data types

        internal enum AndroidMessageComposerResultCode
        {
            Cancelled,
            Sent,
            Unknown
        }

        #endregion
    }
}
#endif