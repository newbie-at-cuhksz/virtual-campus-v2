﻿namespace VoxelBusters.EssentialKit.WebViewCore.Android
{
	public static class Native
	{
		internal const string kBasePackage = "com.voxelbusters.nativeplugins.v2.features.WebView";
		internal const string kClassName = kBasePackage + "." + "WebView";
		internal const string kJavaScriptResultListener = kBasePackage + "." + "IJavaScriptResultListener";
		internal const string kWebViewStateListener = kBasePackage + "." + "IWebViewStateListener";

		#region Nested classes

		internal class Method
		{

		}

		#endregion
	}
}