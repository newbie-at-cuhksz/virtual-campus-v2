﻿#if UNITY_ANDROID
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using VoxelBusters.EssentialKit.Internal;

namespace VoxelBusters.EssentialKit.GameServicesCore.Android
{
    internal class Player : PlayerBase
    {
        #region Properties

        private AndroidJavaObject Plugin
        {
            get;
            set;
        }

        #endregion

        #region Constructors

        public Player(AndroidJavaObject nativeObject)
        {
            Plugin = nativeObject;
        }

        #endregion

        #region Static methods

        public static void LoadPlayers(string[] playerIds, LoadPlayersInternalCallback callback)
        {
            using (AndroidJavaClass javaClass = AndroidPluginUtility.CreateJavaClass(Native.Player.kClassName))
            {
                javaClass.CallStatic(Native.Player.Method.kLoadPlayers, AndroidPluginUtility.GetContext(), (object)playerIds, new LoadPlayersProxyListener(callback));
            }
        }

        #endregion

        #region Base class methods

        protected override string GetIdInternal()
        {
            return Plugin.Call<string>(Native.Player.Method.kGetId);
        }

        protected override string GetAliasInternal()
        {
            return Plugin.Call<string>(Native.Player.Method.kGetAlias);
        }

        protected override string GetDisplayNameInternal()
        {
            return Plugin.Call<string>(Native.Player.Method.kGetDisplayName);
        }

        protected override void LoadImageInternal(LoadImageInternalCallback callback)
        {
            Plugin.Call<string>(Native.Player.Method.kLoadPreviewImage, new LoadImageProxyListener(callback));
        }

        #endregion

    }
}
#endif