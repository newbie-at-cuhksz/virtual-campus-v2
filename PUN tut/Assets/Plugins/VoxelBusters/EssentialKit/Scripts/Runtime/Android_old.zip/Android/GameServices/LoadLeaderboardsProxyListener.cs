﻿#if UNITY_ANDROID
using System;

namespace VoxelBusters.EssentialKit.GameServicesCore.Android
{
    using System.Collections.Generic;
    using Internal;
    using UnityEngine;

    internal class LoadLeaderboardsProxyListener : NativeProxy<LoadLeaderboardsInternalCallback>
    {
        #region Constructors

        public LoadLeaderboardsProxyListener(LoadLeaderboardsInternalCallback callback) : base(callback, Native.Leaderboard.kLoadLeaderboardsListenerInterface)
        {
        }

        #endregion

        #region Callbacks

        private void onLoadLeaderboardsComplete(ILeaderboard[] leaderboards, string error)
        {
            if (m_callback != null)
            {
                Action action = () => m_callback(leaderboards, error);
                DispatchOnMainThread(action);
            }
        }

        public override AndroidJavaObject Invoke(string methodName, AndroidJavaObject[] javaArgs)
        {
            if (methodName == "onLoadLeaderboardsComplete")
            {
                List<ILeaderboard> list = javaArgs[0].GetList((nativeObject) => (ILeaderboard)new Leaderboard(nativeObject));
                string error = javaArgs[1].GetString();

                onLoadLeaderboardsComplete(list != null ? list.ToArray() : null, error);
                return null;
            }
            else
            {
                return base.Invoke(methodName, javaArgs);
            }
        }

        #endregion
    }
}
#endif