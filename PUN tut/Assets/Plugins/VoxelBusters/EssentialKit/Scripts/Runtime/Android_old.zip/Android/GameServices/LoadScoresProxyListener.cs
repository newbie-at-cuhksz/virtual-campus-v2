﻿#if UNITY_ANDROID
using System;

namespace VoxelBusters.EssentialKit.GameServicesCore.Android
{
    using System.Collections.Generic;
    using Internal;
    using UnityEngine;

    internal class LoadScoresProxyListener : NativeProxy<LoadScoresInternalCallback>
    {
        #region Constructors

        public LoadScoresProxyListener(LoadScoresInternalCallback callback) : base(callback, Native.Achievement.kLoadAchievementsListenerInterface)
        {
        }

        #endregion

        #region Callbacks

        private void onLoadScoresComplete(IScore[] scores, string error)
        {
            if (m_callback != null)
            {
                Action action = () => m_callback(scores, error);
                DispatchOnMainThread(action);
            }
        }

        public override AndroidJavaObject Invoke(string methodName, AndroidJavaObject[] javaArgs)
        {
            if (methodName == "onLoadScoresComplete")
            {
                List<IScore> list       = javaArgs[0].GetList((nativeObject) => (IScore) new Achievement(nativeObject));
                string error            = javaArgs[1].GetString();

                onLoadScoresComplete(list != null ? list.ToArray() : null, error);
                return null;
            }
            else
            {
                return base.Invoke(methodName, javaArgs);
            }
        }

        #endregion
    }
}
#endif