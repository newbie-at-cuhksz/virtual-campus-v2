﻿#if UNITY_ANDROID
using VoxelBusters.EssentialKit.Internal;

namespace VoxelBusters.EssentialKit.WebViewCore.Android
{
    internal class WebViewStateProxyListener : NativeProxyBase
    {
        #region Fields

        INativeWebViewStateListener m_listener;

        #endregion

        #region Constructors

        public WebViewStateProxyListener(INativeWebViewStateListener listener) : base(Native.kWebViewStateListener)
        {
            m_listener = listener;
        }

        #endregion

        #region Callbacks

        private void onShow(string error)
        {
            if (m_listener != null)
            {
                DispatchOnMainThread(() => m_listener.OnShow(error));
            }
        }

        private void onHide(string error)
        {
            if (m_listener != null)
            {
                DispatchOnMainThread(() => m_listener.OnHide(error));
            }
        }

        private void onLoadStart(string error)
        {
            if (m_listener != null)
            {
                DispatchOnMainThread(() => m_listener.OnLoadStart(error));
            }
        }

        private void onLoadFinish(string error)
        {
            if (m_listener != null)
            {
                DispatchOnMainThread(() => m_listener.OnLoadFinish(error));
            }
        }

        private void onUrlSchemeMatchFound(string url)
        {
            if (m_listener != null)
            {
                DispatchOnMainThread(() => m_listener.OnURLSchemeMatchFound(url));
            }
        }

        #endregion
    }
}
#endif