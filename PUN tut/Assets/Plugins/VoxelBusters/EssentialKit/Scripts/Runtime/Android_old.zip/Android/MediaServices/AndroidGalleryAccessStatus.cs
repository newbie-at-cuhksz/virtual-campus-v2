﻿#if UNITY_ANDROID
using VoxelBusters.NativePlugins;

namespace VoxelBusters.EssentialKit.MediaServicesCore.Android
{
    #region Data types

    internal enum AndroidGalleryAccessStatus
    {
        NotDetermined,
        Restricted,
        Denied,
        Authorized,
    }

    #endregion
}
#endif