﻿#if UNITY_ANDROID
using System.Collections.Generic;
using UnityEngine;
using VoxelBusters.EssentialKit.Internal;

namespace VoxelBusters.EssentialKit.BillingServicesCore.Android
{
    internal class BillingServicesInterface : NativeBillingServicesInterfaceBase
    {
        #region Properties

        private AndroidJavaObject Plugin
        {
            get;
            set;
        }

        #endregion

        #region Constructors

        public BillingServicesInterface()
        {
            Plugin = AndroidPluginUtility.CreateJavaInstance(Native.kClassName);
            Plugin.Call(Native.Method.kSetPurchaseStateChangeListener, new PurchaseStateChangeProxyListener(InvokeOnPaymentStateChange));
        }

        #endregion

        public override void RetrieveProducts(BillingProductMeta[] productMeta)
        {
            int         length      = productMeta.Length;
            string[]    productIds  = new string[length];

            for(int i=0; i< length; i++)
            {
                productIds[i] = productMeta[i].GetProductIdForActivePlatform();
            }

            Plugin.Call(Native.Method.kRequestForProducts, productIds, new RequestForProductsProxyListener(InvokeOnRequestForProductsFinish));
        }

        public override bool CanMakePayments()
        {
            return Plugin.Call<bool>(Native.Method.kCanMakePayments);
        }

        public override bool StartPayment(IBillingPayment payment, out string error)
        {
            if(CanMakePayments())
            {
                error = null;
                Plugin.Call(Native.Method.kBuyProduct, payment.ProductPlatformId);
                return true;
            }

            error = "Can't make payments";
            return false;
        }

        public override IBillingTransaction[] GetTransactions()
        {
            AndroidJavaObject transactionCollection = Plugin.Call<AndroidJavaObject>(Native.Method.kGetPendingTransactions);

            if (transactionCollection != null)
            {
                List<IBillingTransaction> list = transactionCollection.GetList<IBillingTransaction>(BillingTransaction.FromNativeObject);

                if (list != null)
                {
                    return list.ToArray();
                }
            }

            return null;
        }

        public override void FinishTransactions(IBillingTransaction[] transactions)
        {
            int length = transactions.Length;

            string[] productIds = new string[length];

            for(int i=0; i<length; i++)
            {
                productIds[i] = transactions[i].Payment.ProductPlatformId;
            }

            Plugin.Call(Native.Method.kFinishTransactions, (object)productIds);
        }

        public override void RestorePurchases(string applicationUsername) //@@TODO What is the reason of passing username? Can we restore for someother person who is not logged in too?
        {
            Plugin.Call(Native.Method.kRestorePurchases, new RestoreProductsProxyListener(InvokeOnRestorePurchasesFinish));
        }

        public override bool TryClearingUnfinishedTransactions()
        {
           return Plugin.Call<bool>(Native.Method.kClearUnfinishedTransactions);
        }

        internal class Native
        {
            #region Constant fields

            internal const string kPackage = "com.voxelbusters.nativeplugins.v2.features.billingservices";
            internal const string kClassName = kPackage + "." + "BillingHandler";
            internal const string kRequestProductsListenerInterface = kPackage + "." + "IBillingServices$IRequestProductsListener";
            internal const string kRestoreProductsListenerInterface = kPackage + "." + "IBillingServices$IRestoreProductsListener";
            internal const string kPurchaseStateChangeListenerInterface = kPackage + "." + "IBillingServices$IPurchaseStateChangeListener";

            #endregion

            #region Nested types

            internal class Method
            {
                internal const string kInitialise = "initialise";
                internal const string kSetPurchaseStateChangeListener = "setPurchaseStateChangeListener";
                internal const string kCanMakePayments = "canMakePayments";
                internal const string kRequestForProducts = "requestForProducts";
                internal const string kBuyProduct = "buyProduct";
                internal const string kGetPendingTransactions = "getPendingTransactions";
                internal const string kFinishTransactions = "finishPendingTransactions";
                internal const string kRestorePurchases = "requestRestorePurchases";
                internal const string kClearUnfinishedTransactions = "clearUnfinishedTransactions";
            }

            #endregion
        }
    }
}
#endif