﻿#if UNITY_ANDROID
using System;

namespace VoxelBusters.EssentialKit.CloudServicesCore.Android
{
    using System.Collections.Generic;
    using Internal;
    using UnityEngine;
    using VoxelBusters.NativePlugins.Internal;

    internal class SavedDataChangeProxyListener : NativeProxy<SavedDataChangeInternalCallback>
    {
        #region Constructors

        public SavedDataChangeProxyListener(SavedDataChangeInternalCallback callback) : base(callback, CloudServicesInterface.Native.kSavedDataChangeListenerInterface)
        {
        }

        #endregion

        #region Callbacks

        private void onSavedDataChange(CloudSavedDataChangeReasonCode changeReason, string[] changedKeys)
        {
            if (m_callback != null)
            {
                Action action = () => m_callback(changeReason, changedKeys);
                DispatchOnMainThread(action);
            }
        }

        public override AndroidJavaObject Invoke(string methodName, AndroidJavaObject[] javaArgs)
        {
            if (methodName == "onSavedDataChange")
            {
                AndroidSavedDataChangeReasonCode    reasonCode  = (AndroidSavedDataChangeReasonCode)javaArgs[0].Call<int>("ordinal");
                List<string>                        changedKeys = javaArgs[1].GetList<string>();

                onSavedDataChange(Convert(reasonCode), (changedKeys == null) ? null : changedKeys.ToArray());
                return null;
            }
            else
            {
                return base.Invoke(methodName, javaArgs);
            }
        }

        #endregion

        #region Helpers

        private CloudSavedDataChangeReasonCode Convert(AndroidSavedDataChangeReasonCode reasonCode)
        {
            switch (reasonCode)
            {
                case AndroidSavedDataChangeReasonCode.ServerChange:
                    return CloudSavedDataChangeReasonCode.ServerChange;

                case AndroidSavedDataChangeReasonCode.InitialSyncChange:
                    return CloudSavedDataChangeReasonCode.InitialSyncChange;

                case AndroidSavedDataChangeReasonCode.QuotaViolationChange:
                    return CloudSavedDataChangeReasonCode.QuotaViolationChange;

                case AndroidSavedDataChangeReasonCode.AccountChange:
                    return CloudSavedDataChangeReasonCode.AccountChange;

                default:
                    throw ExceptionFactory.SwitchCaseNotImplementedException(reasonCode);
            }
        }

        #endregion

        #region Data types

        internal enum AndroidSavedDataChangeReasonCode
        {
            ServerChange,
            InitialSyncChange,
            QuotaViolationChange,
            AccountChange
        }

        #endregion
    }
}
#endif