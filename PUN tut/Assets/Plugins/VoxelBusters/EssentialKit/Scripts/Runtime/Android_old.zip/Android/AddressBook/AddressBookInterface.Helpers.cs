﻿#if UNITY_ANDROID
using System;
using System.Collections.Generic;
using UnityEngine;

namespace VoxelBusters.EssentialKit.AddressBookCore.Android
{
    using Internal;
    internal partial class AddressBookInterface : NativeAddressBookInterfaceBase
    {
        #region Helper classes

        internal class Native
        {
            #region Constant fields

            internal const string kPackage                          = "com.voxelbusters.nativeplugins.v2.features.addressbook";

            internal const string kClassName                        = kPackage + "." + "AddressBookHandler";

            internal const string kReadContactsListenerInterface    = kPackage + "." + "IAddressBookHandler$IReadContactsListener";

            internal const string kRequestAccessListenerInterface   = kPackage + "." + "IAddressBookHandler$IRequestContactsPermissionListener";

            #endregion

            #region Nested types

            internal class Method
            {
                internal const string kInitialise           = "initialise";

                internal const string kReadContacts         = "readContacts";

                internal const string kRequestPermission    = "requestPermission";

                internal const string kIsAuthorized         = "isAuthorized";
            }

            #endregion
        }

        internal class ReadContactsProxyListener : NativeProxy<ReadContactsInternalCallback>
        {
            #region Constructors

            public ReadContactsProxyListener(ReadContactsInternalCallback m_callback) : base(m_callback, Native.kReadContactsListenerInterface)
            {
            }

            #endregion

            #region Callbacks

            private void onReadContactsComplete(List<AddressBookContact> contacts, string error)
            {
                if (m_callback != null)
                {
                    IAddressBookContact[] contactsArray = null;

                    if(string.IsNullOrEmpty(error))
                    {
                        if(contacts != null)
                        {
                            contactsArray = contacts.ToArray();
                        }
                    }

                    Action action = () => m_callback(contactsArray, error);
                    DispatchOnMainThread(action);
                }
            }

            public override AndroidJavaObject Invoke(string methodName, AndroidJavaObject[] javaArgs)
            {
                if (methodName == "onReadContactsComplete")
                {
                    List<AddressBookContact> list = javaArgs[0].GetList(AddressBookContact.FromNativeObject);
                    string error = javaArgs[1].GetString();

                    onReadContactsComplete(list, error);
                    return null;
                }
                else
                {
                    return base.Invoke(methodName, javaArgs);
                }
            }

            #endregion
        }

        internal class PermissionRequestProxyListener : NativeProxy<RequestAccessInternalCallback>
        {
            #region Constructors

            public PermissionRequestProxyListener(RequestAccessInternalCallback callback) : base(callback, Native.kRequestAccessListenerInterface)
            {
            }

            #endregion

            #region Callbacks

            void onPermissionRequestComplete(bool success, string error)
            {
                if (m_callback != null)
                {
                    Action action = () => m_callback(success ? AddressBookAccessStatus.Authorized : AddressBookAccessStatus.Denied, error);
                    DispatchOnMainThread(action);
                }
            }

            #endregion
        }

        #endregion
    }
}
#endif
