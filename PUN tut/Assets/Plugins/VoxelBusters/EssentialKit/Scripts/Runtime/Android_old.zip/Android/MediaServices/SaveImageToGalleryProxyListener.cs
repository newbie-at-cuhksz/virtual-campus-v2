﻿#if UNITY_ANDROID
using System;
using VoxelBusters.EssentialKit.Internal;

namespace VoxelBusters.EssentialKit.MediaServicesCore.Android
{
    internal class SaveImageToGalleryProxyListener : NativeProxy<SaveImageToGalleryInternalCallback>
    {
        #region Constructors

        public SaveImageToGalleryProxyListener(SaveImageToGalleryInternalCallback callback) : base(callback, Native.kRequestCameraAccessListener)
        {
        }

        #endregion

        #region Callbacks

        private void onSaveImageToGalleryComplete(bool success, string error)
        {
            if (m_callback != null)
            {
                Action action = () =>
                {
                    m_callback(success, error);
                };
                DispatchOnMainThread(action);
            }
        }

        #endregion
    }
}
#endif