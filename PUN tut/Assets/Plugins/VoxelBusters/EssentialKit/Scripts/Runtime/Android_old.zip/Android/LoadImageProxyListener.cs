﻿#if UNITY_ANDROID
using UnityEngine;
using System;

namespace VoxelBusters.EssentialKit.Internal
{
    internal class LoadImageProxyListener : NativeProxy<LoadImageInternalCallback>
    {
        internal const string kPackage          = "com.voxelbusters.nativeplugins.v2.common.interfaces";
        internal const string kInterfaceName    = kPackage + "." + "ILoadUriListener";

        #region Constructors

        public LoadImageProxyListener(LoadImageInternalCallback callback) : base(callback, kInterfaceName)
        {
        }

        #endregion

        #region Callbacks

        private void onLoadComplete(byte[] data)
        {
            if (m_callback != null)
            {
                Action action = () =>
                {
                    m_callback(data, null);
                };
                DispatchOnMainThread(action);
            }
        }

        public override AndroidJavaObject Invoke(string methodName, AndroidJavaObject[] javaArgs)
        {
            if (methodName == "onLoadComplete")
            {
                onLoadComplete(javaArgs[0].GetArray<byte[]>());
                return null;
            }
            else
                return base.Invoke(methodName, javaArgs);
        }

        #endregion
    }
}
#endif