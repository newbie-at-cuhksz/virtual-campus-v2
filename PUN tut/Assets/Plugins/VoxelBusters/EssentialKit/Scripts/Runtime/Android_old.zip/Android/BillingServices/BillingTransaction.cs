﻿#if UNITY_ANDROID
using UnityEngine;
using System.Collections;
using VoxelBusters.EssentialKit.Internal;
using System;

namespace VoxelBusters.EssentialKit.BillingServicesCore.Android
{
    internal class BillingTransaction : BillingTransactionBase
    {
        protected override string GetErrorInternal()
        {
            throw new NotImplementedException();
        }

        protected override DateTime GetTransactionDateUTCInternal()
        {
            throw new NotImplementedException();
        }

        protected override BillingTransactionState GetTransactionStateInternal()
        {
            throw new NotImplementedException();
        }

        #region Constructors

        public BillingTransaction(string platformId, IBillingPayment payment, AndroidJavaObject nativeObject) : base(platformId, payment)
        {
            //product.Id = nativeObject.Call<string>("");
            //product.Id = nativeObject.Call<string>("");
            //product.Id = nativeObject.Call<string>("");
            //product.Id = nativeObject.Call<string>("");
            //product.Id = nativeObject.Call<string>("");
            //product.Id = nativeObject.Call<string>("");
            //TODO
        }

        #endregion


        #region Internal methods

        internal static BillingTransaction FromNativeObject(AndroidJavaObject nativeObject)
        {
            string          transactionId   = GetTransactionId(nativeObject);
            IBillingPayment payment         = GetPayment(nativeObject);

            BillingTransaction transaction  = new BillingTransaction(transactionId, payment, nativeObject);
            return transaction;
        }

        private static string GetTransactionId(AndroidJavaObject nativeObject)
        {
            return nativeObject.Call<string>("transactionId");
        }

        private static IBillingPayment GetPayment(AndroidJavaObject nativeObject)
        {
            throw new NotImplementedException();
        }

        #endregion
    }
}
#endif