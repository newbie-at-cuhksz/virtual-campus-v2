﻿#if UNITY_ANDROID
using UnityEngine;

namespace VoxelBusters.EssentialKit.BillingServicesCore.Android
{
    internal class BillingProduct : BillingProductBase
    {
        protected override string GetLocalizedDescriptionInternal()
        {
            throw new System.NotImplementedException();
        }

        protected override string GetLocalizedPriceInternal()
        {
            throw new System.NotImplementedException();
        }

        protected override string GetLocalizedTitleInternal()
        {
            throw new System.NotImplementedException();
        }
        
        protected override string GetPriceInternal()
        {
            throw new System.NotImplementedException();
        }

        #region Constructors

        public BillingProduct(string platformId, AndroidJavaObject nativeObject) : base(platformId)
        {
            //product.Id = nativeObject.Call<string>("");
            //product.Id = nativeObject.Call<string>("");
            //product.Id = nativeObject.Call<string>("");
            //product.Id = nativeObject.Call<string>("");
            //product.Id = nativeObject.Call<string>("");
            //product.Id = nativeObject.Call<string>("");
            //TODO
        }

        #endregion


        #region Internal methods

        internal static BillingProduct FromNativeObject(AndroidJavaObject nativeObject)
        {
            string productId = GetProductId(nativeObject);
            BillingProduct product = new BillingProduct(productId, nativeObject);
            return product;
        }

        private static string GetProductId(AndroidJavaObject nativeObject)
        {
            return nativeObject.Call<string>("productId");
        }

        #endregion
    }
}
#endif