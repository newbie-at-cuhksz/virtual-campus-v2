﻿#if UNITY_ANDROID
using System;
using System.Collections.Generic;
using UnityEngine;

namespace VoxelBusters.EssentialKit.BillingServicesCore.Android
{
    using Internal;
    internal class PurchaseStateChangeProxyListener : NativeProxy<PaymentStateChangeInternalCallback>
    {
        #region Constructors

        public PurchaseStateChangeProxyListener(PaymentStateChangeInternalCallback callback) : base(callback, BillingServicesInterface.Native.kPurchaseStateChangeListenerInterface)
        {
        }

        #endregion

        #region Callbacks

        private void onPurchaseStateChangeComplete(List<BillingTransaction> transactions)
        {
            if (m_callback != null)
            {
                Action action = () => m_callback((transactions == null) ? null : transactions.ToArray());
                DispatchOnMainThread(action);
            }
        }

        public override AndroidJavaObject Invoke(string methodName, AndroidJavaObject[] javaArgs)
        {
            if (methodName == "onPurchaseStateChangeComplete")
            {
                List<BillingTransaction>    transactions    = javaArgs[0].GetList(BillingTransaction.FromNativeObject);

                onPurchaseStateChangeComplete(transactions);
                return null;
            }
            else
            {
                return base.Invoke(methodName, javaArgs);
            }
        }

        #endregion
    }
}
#endif