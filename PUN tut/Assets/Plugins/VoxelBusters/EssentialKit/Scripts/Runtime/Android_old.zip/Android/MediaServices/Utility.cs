﻿#if UNITY_ANDROID
using VoxelBusters.NativePlugins.Internal;
using VoxelBusters.EssentialKit.MediaServicesCore.Android;

namespace VoxelBusters.EssentialKit.MediaServicesCore.Android
{
    public static class Utility
    {
        internal static GalleryAccessStatus Convert(this AndroidGalleryAccessStatus resultCode)
        {
            switch (resultCode)
            {
                case AndroidGalleryAccessStatus.NotDetermined:
                    return GalleryAccessStatus.NotDetermined;

                case AndroidGalleryAccessStatus.Restricted:
                    return GalleryAccessStatus.Restricted;

                case AndroidGalleryAccessStatus.Denied:
                    return GalleryAccessStatus.Denied;

                case AndroidGalleryAccessStatus.Authorized:
                    return GalleryAccessStatus.Authorized;
                default:
                    throw ExceptionFactory.SwitchCaseNotImplementedException(resultCode);
            }
        }

        internal static CameraAccessStatus Convert(this AndroidCameraAccessStatus status)
        {
            switch (status)
            {
                case AndroidCameraAccessStatus.Denied:
                    return CameraAccessStatus.Denied;

                case AndroidCameraAccessStatus.Authorized:
                    return CameraAccessStatus.Authorized;

                case AndroidCameraAccessStatus.Restricted:
                    return CameraAccessStatus.Restricted;

                case AndroidCameraAccessStatus.NotDetermined:
                    return CameraAccessStatus.NotDetermined;

                default:
                    throw ExceptionFactory.SwitchCaseNotImplementedException(status);
            }
        }
    }
}
#endif