﻿#if UNITY_ANDROID
using System;

namespace VoxelBusters.EssentialKit.GameServicesCore.Android
{
    using System.Collections.Generic;
    using Internal;
    using UnityEngine;

    internal class LoadPlayersProxyListener : NativeProxy<LoadPlayersInternalCallback>
    {
        #region Constructors

        public LoadPlayersProxyListener(LoadPlayersInternalCallback callback) : base(callback, Native.Player.kLoadPlayersListener)
        {
        }

        #endregion

        #region Callbacks

        private void onLoadPlayersComplete(IPlayer[] players, string error)
        {
            if (m_callback != null)
            {
                Action action = () => m_callback(players, error);
                DispatchOnMainThread(action);
            }
        }

        public override AndroidJavaObject Invoke(string methodName, AndroidJavaObject[] javaArgs)
        {
            if (methodName == "onLoadPlayersComplete")
            {
                List<IPlayer> list       = javaArgs[0].GetList((nativeObject) => (IPlayer) new Player(nativeObject));
                string error            = javaArgs[1].GetString();

                onLoadPlayersComplete(list != null ? list.ToArray() : null, error);
                return null;
            }
            else
            {
                return base.Invoke(methodName, javaArgs);
            }
        }

        #endregion
    }
}
#endif