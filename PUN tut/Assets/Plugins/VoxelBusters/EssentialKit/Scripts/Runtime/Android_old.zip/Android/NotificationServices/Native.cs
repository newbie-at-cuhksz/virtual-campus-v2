﻿namespace VoxelBusters.NativePlugins.NotificationServicesCore.Android
{
    public static class Native
    {
        internal const string kBasePackage = "com.voxelbusters.nativeplugins.v2.features.notificationservices";
        internal const string kClassName = kBasePackage + "." + "NotificationServices";

        #region Nested classes

        internal class Method
        {

        }

        #endregion
    }
}