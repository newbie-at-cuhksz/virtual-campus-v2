﻿#if UNITY_ANDROID
using System;
using System.Collections.Generic;
using UnityEngine;

namespace VoxelBusters.EssentialKit.BillingServicesCore.Android
{
    using Internal;
    internal class RestoreProductsProxyListener : NativeProxy<RestorePurchasesInternalCallback>
    {
        #region Constructors

        public RestoreProductsProxyListener(RestorePurchasesInternalCallback callback) : base(callback, BillingServicesInterface.Native.kRestoreProductsListenerInterface)
        {
        }

        #endregion

        #region Callbacks

        private void onRestoreProductsComplete(List<BillingTransaction> transactions, string error)
        {
            if (m_callback != null)
            {
                Action action = () => m_callback((transactions == null) ? null : transactions.ToArray(), error);
                DispatchOnMainThread(action);
            }
        }

        public override AndroidJavaObject Invoke(string methodName, AndroidJavaObject[] javaArgs)
        {
            if (methodName == "onRestoreProductsComplete")
            {
                List<BillingTransaction>    transactions            = javaArgs[0].GetList(BillingTransaction.FromNativeObject);
                string                              error           = javaArgs[1].GetString();

                onRestoreProductsComplete(transactions, error);
                return null;
            }
            else
            {
                return base.Invoke(methodName, javaArgs);
            }
        }

        #endregion
    }
}
#endif