﻿#if UNITY_ANDROID
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using VoxelBusters.CoreLibrary;
using VoxelBusters.EssentialKit.Internal;

namespace VoxelBusters.EssentialKit.SharingServicesCore.Android
{
    internal partial class AndroidShareSheetInterface : NativeShareSheetBase
    {
        #region Properties

        private AndroidJavaObject Plugin
        {
            get;
            set;
        }

        #endregion

        #region Constructors

        public AndroidShareSheetInterface()
        {
            Plugin = AndroidPluginUtility.CreateJavaInstance(Native.kClassName);
        }

        #endregion

        #region INativeShareSheetInterface Implementation

        public override void AddImage(byte[] imageData)
        {
            Plugin.Call(Native.Method.kAddAttachmentData, imageData, MimeType.kPNGImage, "share.png"); //TODO find the mime type from imageData
        }

        public override void AddScreenshot()
        {
            string filePath = TextureExtensions.TakeScreenshot("screenshot.png");
            Plugin.Call(Native.Method.kAddFileAtPathAsync, filePath, MimeType.kPNGImage);
        }

        public override void AddText(string text)
        {
            Plugin.Call(Native.Method.kSetMessage, text, false);
        }

        public override void AddURL(URLString url)
        {
            Plugin.Call(Native.Method.kSetURL, url.ToString());
        }

        public override void Show(Vector2 screenPosition)
        {
            Plugin.Call(Native.Method.kShow, new ShareSheetProxyListener(InvokeOnClose));
        }

        #endregion
    }
}
#endif