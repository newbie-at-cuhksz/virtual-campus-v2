﻿#if UNITY_ANDROID
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using VoxelBusters.CoreLibrary;
using VoxelBusters.EssentialKit.Internal;

namespace VoxelBusters.EssentialKit.SharingServicesCore.Android
{
    internal partial class MessageComposerInterface : NativeMessageComposerBase
    {
        #region Properties

        private AndroidJavaObject Plugin
        {
            get;
            set;
        }

        #endregion

        #region Constructors

        public MessageComposerInterface()
        {
            Plugin = AndroidPluginUtility.CreateJavaInstance(Native.kClassName);
        }

        #endregion

        #region Static methods

        public static bool CanSendText()
        {
            using (AndroidJavaClass javaClass = AndroidPluginUtility.CreateJavaClass(Native.kClassName))
            {
                return javaClass.CallStatic<bool>(Native.Method.kCanSendText, AndroidPluginUtility.GetContext());
            }
        }

        public static bool CanSendAttachments()
        {
            using (AndroidJavaClass javaClass = AndroidPluginUtility.CreateJavaClass(Native.kClassName))
            {
                return javaClass.CallStatic<bool>(Native.Method.kCanSendAttachments, AndroidPluginUtility.GetContext());
            }
        }

        public static bool CanSendSubject()
        {
            using (AndroidJavaClass javaClass = AndroidPluginUtility.CreateJavaClass(Native.kClassName))
            {
                return javaClass.CallStatic<bool>(Native.Method.kCanSendSubject, AndroidPluginUtility.GetContext());
            }
        }

        #endregion

        #region Base class overrides

        public override void AddAttachmentData(byte[] data, string mimeType, string fileName)
        {
            Plugin.Call(Native.Method.kAddAttachmentData, data, mimeType, fileName);
        }

        public override void AddImage(Texture2D image, string fileName)
        {
            AddAttachmentData(image.EncodeToPNG(), MimeType.kPNGImage, fileName);
        }

        public override void AddScreenshot(string fileName)
        {
            string filePath = TextureExtensions.TakeScreenshot(fileName);
            Plugin.Call(Native.Method.kAddFileAtPathAsync, filePath, MimeType.kPNGImage);
        }

        public override void SetBody(string value)
        {
            Plugin.Call(Native.Method.kSetMessage, value, false);
        }

        public override void SetRecipients(params string[] values)
        {
            Plugin.Call(Native.Method.kSetToRecipients, (object)values);
        }

        public override void SetSubject(string value)
        {
            Plugin.Call(Native.Method.kSetTitle, value);
        }

        public override void Show()
        {
            Plugin.Call(Native.Method.kShow, new MessageComposerProxyListener(InvokeOnClose));
        }

        #endregion
    }
}
#endif