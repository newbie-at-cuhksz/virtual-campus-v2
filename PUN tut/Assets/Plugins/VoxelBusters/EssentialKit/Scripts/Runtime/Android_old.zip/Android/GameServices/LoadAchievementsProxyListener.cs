﻿#if UNITY_ANDROID
using System;

namespace VoxelBusters.EssentialKit.GameServicesCore.Android
{
    using System.Collections.Generic;
    using Internal;
    using UnityEngine;

    internal class LoadAchievementsProxyListener : NativeProxy<LoadAchievementsInternalCallback>
    {
        #region Constructors

        public LoadAchievementsProxyListener(LoadAchievementsInternalCallback callback) : base(callback, Native.Achievement.kLoadAchievementsListenerInterface)
        {
        }

        #endregion

        #region Callbacks

        private void onLoadAchievementsComplete(IAchievement[] achievements, string error)
        {
            if (m_callback != null)
            {
                Action action = () => m_callback(achievements, error);
                DispatchOnMainThread(action);
            }
        }

        public override AndroidJavaObject Invoke(string methodName, AndroidJavaObject[] javaArgs)
        {
            if (methodName == "onLoadAchievementsComplete")
            {
                List<IAchievement> list  = javaArgs[0].GetList((nativeObject) => (IAchievement) new Achievement(nativeObject));
                string error            = javaArgs[1].GetString();

                onLoadAchievementsComplete(list != null ? list.ToArray() : null, error);
                return null;
            }
            else
            {
                return base.Invoke(methodName, javaArgs);
            }
        }

        #endregion
    }
}
#endif